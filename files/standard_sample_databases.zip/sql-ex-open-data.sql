set bail on;

-- child tables:
recreate table pc (
  code  int      not null,
  model varchar(50) not null,
  speed int      not null,
  ram   int      not null,
  hd    double precision not null,
  cd    varchar(10) not null,
  price numeric(12,2),
  constraint pk_pc primary key (code) using index pk_pc
);

recreate table printer (
  code  int not null,
  model varchar(50) not null,
  color char(1) not null,
  type  varchar(10) not null, -- orig: type
  price numeric(12,2),
  constraint pk_printer primary key (code) using index pk_printer
);

recreate table laptop (
  code   int      not null,
  model  varchar(50) not null,
  speed  int      not null,
  ram    int      not null,
  hd     double precision  not null,
  price  numeric(12,2),
  screen int      not null,
  constraint pk_laptop primary key (code) using index pk_laptop
);
recreate table outcomes (
  ship   varchar(50) not null,
  battle varchar(20) not null,
  result varchar(10) not null,
  constraint pk_outcomes primary key (ship,battle) using index pk_outcomes
);

recreate table ships (
  name     varchar(50) not null,
  class    varchar(50) not null,
  launched int,
  constraint pk_ships primary key (name) using index pk_ships
);

recreate table pass_in_trip (
  trip_no int      not null,
  pdate   date not null, -- orig: date
  id_psg  int      not null,
  place   char(10)     not null,
  constraint pk_pass_in_trip primary key (trip_no, pdate, id_psg) using index pk_pass_in_trip
);
recreate table trip (
  trip_no   int not null,
  id_comp   int not null,
  plane     char(10) not null,
  town_from char(25) not null,
  town_to   char(25) not null,
  time_out  timestamp not null,
  time_in   timestamp not null,
  constraint pk_trip primary key (trip_no) using index pk_trip
);

recreate table utb (
  b_datetime timestamp not null,
  b_q_id     int not null,
  b_v_id     int not null,
  b_vol      int not null,
  constraint pk_utb primary key (b_datetime, b_q_id, b_v_id) using index pk_utb
);

-------------
-- parent tables:
recreate table battles (
  name varchar(20) not null
  ,bdate date not null -- orig: date
  ,constraint pk_battles primary key (name) using index pk_battles
);

recreate table classes (
  class        varchar(50) not null,
  type        varchar(2)  not null, -- orig: type
  country      varchar(20) not null,
  numguns      int,
  bore         double precision,
  displacement int,
  constraint pk_classes primary key (class) using index pk_class
);

recreate table company (
  id_comp int  not null,
  name    char(10) not null,
  constraint pk_company primary key (id_comp) using index pk_company
);

recreate table income (
  code  int      not null,
  point int      not null,
  pdate date not null, -- orig: date
  inc   numeric(12,2) not null,
  constraint pk_income primary key (code) using index pk_income
);

recreate table income_o (
  point int      not null,
  pdate date not null, -- orig: date
  inc   numeric(12,2) not null,
  constraint pk_income_o primary key (point, pdate) using index pk_income_o
);


recreate table outcome (
  code  int      not null,
  point int      not null,
  pdate date not null, -- orig: date
  out   numeric(12,2) not null,
  constraint pk_outcome primary key (code) using index pk_outcome
);

recreate table outcome_o (
  point int      not null,
  pdate  date not null, -- orig: date
  out   numeric(12,2) not null,
  constraint pk_outcome_o primary key (point, pdate) using index pk_outcome_o
);


recreate table passenger (
  id_psg int  not null,
  name   char(20) not null,
  constraint pk_passenger primary key (id_psg) using index pk_passenger
);


recreate table product (
  maker varchar(10) not null,
  model varchar(50) not null,
  type  varchar(50) not null, -- orig: type
  constraint pk_model primary key (model) using index pk_product
);

recreate table utq (
  q_id   int      not null,
  q_name varchar(35) not null,
  constraint pk_utq primary key (q_id) using index pk_utq
);

recreate table utv (
  v_id    int      not null,
  v_name  varchar(35) not null,
  v_color char(1)      not null,
  constraint pk_utv primary key (v_id) using index pk_utv
);

-------------------------------
-- add foreign keys:
alter table laptop
  add constraint fk_laptop_product foreign key (
    model
  ) references product (
    model
  );
alter table outcomes
  add constraint fk_outcomes_battles foreign key (
    battle
  ) references battles (
    name
  );

alter table pass_in_trip
  add constraint fk_pass_in_trip_passenger foreign key (
    id_psg
  ) references passenger (
    id_psg
  );

alter table pass_in_trip
  add constraint fk_pass_in_trip_trip foreign key (
    trip_no
  ) references trip (
    trip_no
  );

alter table pc
  add constraint fk_pc_product foreign key (
    model
  ) references product (
    model
  );

alter table printer
  add constraint fk_printer_product foreign key (
    model
  ) references product (
    model
  );

alter table ships
  add constraint fk_ships_classes foreign key (
    class
  ) references classes (
    class
  );

alter table trip
  add constraint fk_trip_company foreign key (
    id_comp
  ) references company (
    id_comp
  );

alter table utb
  add constraint fk_utb_utq foreign key (
    b_q_id
  ) references utq (
    q_id
  );

alter table utb
  add constraint fk_utb_utv foreign key (
    b_v_id
  ) references utv (
    v_id
  );
commit;
---------------------------------------------
-- data:

insert into battles (name, bdate) values('Guadalcanal', timestamp'1942-11-15 00:00:00');
insert into battles (name, bdate) values('North Atlantic', timestamp'1941-05-25 00:00:00');
insert into battles (name, bdate) values('North Cape', timestamp'1943-12-26 00:00:00');
insert into battles (name, bdate) values('Surigao Strait', timestamp'1944-10-25 00:00:00');
insert into battles (name, bdate) values('#Cuba62a', timestamp'1962-10-20 00:00:00');
insert into battles (name, bdate) values('#Cuba62b', timestamp'1962-10-25 00:00:00');

insert into classes (class, type, country, numguns, bore, displacement) values('Bismarck', 'bb', 'Germany', 8, 15, 42000);
insert into classes (class, type, country, numguns, bore, displacement) values('Iowa', 'bb', 'USA', 9, 16, 46000);
insert into classes (class, type, country, numguns, bore, displacement) values('Kongo', 'bc', 'Japan', 8, 14, 32000);
insert into classes (class, type, country, numguns, bore, displacement) values('North Carolina', 'bb', 'USA', 12, 16, 37000);
insert into classes (class, type, country, numguns, bore, displacement) values('Renown', 'bc', 'Gt.Britain', 6, 15, 32000);
insert into classes (class, type, country, numguns, bore, displacement) values('Revenge', 'bb', 'Gt.Britain', 8, 15, 29000);
insert into classes (class, type, country, numguns, bore, displacement) values('Tennessee', 'bb', 'USA', 12, 14, 32000);
insert into classes (class, type, country, numguns, bore, displacement) values('Yamato', 'bb', 'Japan', 9, 18, 65000);

insert into company (id_comp, name) values(1, 'Don_avia  ');
insert into company (id_comp, name) values(2, 'Aeroflot  ');
insert into company (id_comp, name) values(3, 'Dale_avia ');
insert into company (id_comp, name) values(4, 'air_France');
insert into company (id_comp, name) values(5, 'British_AW');


insert into income (code, point, pdate, inc) values(1, 1, timestamp'2001-03-22 00:00:00', 15000.00);
insert into income (code, point, pdate, inc) values(2, 1, timestamp'2001-03-23 00:00:00', 15000.00);
insert into income (code, point, pdate, inc) values(3, 1, timestamp'2001-03-24 00:00:00', 3600.00);
insert into income (code, point, pdate, inc) values(4, 2, timestamp'2001-03-22 00:00:00', 10000.00);
insert into income (code, point, pdate, inc) values(5, 2, timestamp'2001-03-24 00:00:00', 1500.00);
insert into income (code, point, pdate, inc) values(6, 1, timestamp'2001-04-13 00:00:00', 5000.00);
insert into income (code, point, pdate, inc) values(7, 1, timestamp'2001-05-11 00:00:00', 4500.00);
insert into income (code, point, pdate, inc) values(8, 1, timestamp'2001-03-22 00:00:00', 15000.00);
insert into income (code, point, pdate, inc) values(9, 2, timestamp'2001-03-24 00:00:00', 1500.00);
insert into income (code, point, pdate, inc) values(10, 1, timestamp'2001-04-13 00:00:00', 5000.00);
insert into income (code, point, pdate, inc) values(11, 1, timestamp'2001-03-24 00:00:00', 3400.00);
insert into income (code, point, pdate, inc) values(12, 3, timestamp'2001-09-13 00:00:00', 1350.00);
insert into income (code, point, pdate, inc) values(13, 3, timestamp'2001-09-13 00:00:00', 1750.00);


insert into income_o (point, pdate, inc) values(1, timestamp'2001-03-22 00:00:00', 15000.00);
insert into income_o (point, pdate, inc) values(1, timestamp'2001-03-23 00:00:00', 15000.00);
insert into income_o (point, pdate, inc) values(1, timestamp'2001-03-24 00:00:00', 3400.00);
insert into income_o (point, pdate, inc) values(1, timestamp'2001-04-13 00:00:00', 5000.00);
insert into income_o (point, pdate, inc) values(1, timestamp'2001-05-11 00:00:00', 4500.00);
insert into income_o (point, pdate, inc) values(2, timestamp'2001-03-22 00:00:00', 10000.00);
insert into income_o (point, pdate, inc) values(2, timestamp'2001-03-24 00:00:00', 1500.00);
insert into income_o (point, pdate, inc) values(3, timestamp'2001-09-13 00:00:00', 11500.00);
insert into income_o (point, pdate, inc) values(3, timestamp'2001-10-02 00:00:00', 18000.00);


insert into product (maker, model, type) values('B', '1121', 'PC');
insert into product (maker, model, type) values('A', '1232', 'PC');
insert into product (maker, model, type) values('A', '1233', 'PC');
insert into product (maker, model, type) values('E', '1260', 'PC');
insert into product (maker, model, type) values('A', '1276', 'Printer');
insert into product (maker, model, type) values('D', '1288', 'Printer');
insert into product (maker, model, type) values('A', '1298', 'Laptop');
insert into product (maker, model, type) values('C', '1321', 'Laptop');
insert into product (maker, model, type) values('A', '1401', 'Printer');
insert into product (maker, model, type) values('A', '1408', 'Printer');
insert into product (maker, model, type) values('D', '1433', 'Printer');
insert into product (maker, model, type) values('E', '1434', 'Printer');
insert into product (maker, model, type) values('B', '1750', 'Laptop');
insert into product (maker, model, type) values('A', '1752', 'Laptop');
insert into product (maker, model, type) values('E', '2113', 'PC');
insert into product (maker, model, type) values('E', '2112', 'PC');

insert into laptop (code, model, speed, ram, hd, price, screen) values(1, '1298', 350, 32, 4, 700.00, 11);
insert into laptop (code, model, speed, ram, hd, price, screen) values(2, '1321', 500, 64, 8, 970.00, 12);
insert into laptop (code, model, speed, ram, hd, price, screen) values(3, '1750', 750, 128, 12, 1200.00, 14);
insert into laptop (code, model, speed, ram, hd, price, screen) values(4, '1298', 600, 64, 10, 1050.00, 15);
insert into laptop (code, model, speed, ram, hd, price, screen) values(5, '1752', 750, 128, 10, 1150.00, 14);
insert into laptop (code, model, speed, ram, hd, price, screen) values(6, '1298', 450, 64, 10, 950.00, 12);

insert into outcome (code, point, pdate, out) values(1, 1, timestamp'2001-03-14 00:00:00', 15348.00);
insert into outcome (code, point, pdate, out) values(2, 1, timestamp'2001-03-24 00:00:00', 3663.00);
insert into outcome (code, point, pdate, out) values(3, 1, timestamp'2001-03-26 00:00:00', 1221.00);
insert into outcome (code, point, pdate, out) values(4, 1, timestamp'2001-03-28 00:00:00', 2075.00);
insert into outcome (code, point, pdate, out) values(5, 1, timestamp'2001-03-29 00:00:00', 2004.00);
insert into outcome (code, point, pdate, out) values(6, 1, timestamp'2001-04-11 00:00:00', 3195.04);
insert into outcome (code, point, pdate, out) values(7, 1, timestamp'2001-04-13 00:00:00', 4490.00);
insert into outcome (code, point, pdate, out) values(8, 1, timestamp'2001-04-27 00:00:00', 3110.00);
insert into outcome (code, point, pdate, out) values(9, 1, timestamp'2001-05-11 00:00:00', 2530.00);
insert into outcome (code, point, pdate, out) values(10, 2, timestamp'2001-03-22 00:00:00', 1440.00);
insert into outcome (code, point, pdate, out) values(11, 2, timestamp'2001-03-29 00:00:00', 7848.00);
insert into outcome (code, point, pdate, out) values(12, 2, timestamp'2001-04-02 00:00:00', 2040.00);
insert into outcome (code, point, pdate, out) values(13, 1, timestamp'2001-03-24 00:00:00', 3500.00);
insert into outcome (code, point, pdate, out) values(14, 2, timestamp'2001-03-22 00:00:00', 1440.00);
insert into outcome (code, point, pdate, out) values(15, 1, timestamp'2001-03-29 00:00:00', 2006.00);
insert into outcome (code, point, pdate, out) values(16, 3, timestamp'2001-09-13 00:00:00', 1200.00);
insert into outcome (code, point, pdate, out) values(17, 3, timestamp'2001-09-13 00:00:00', 1500.00);
insert into outcome (code, point, pdate, out) values(18, 3, timestamp'2001-09-14 00:00:00', 1150.00);

insert into outcome_o (point, pdate, out) values(1, timestamp'2001-03-14 00:00:00', 15348.00);
insert into outcome_o (point, pdate, out) values(1, timestamp'2001-03-24 00:00:00', 3663.00);
insert into outcome_o (point, pdate, out) values(1, timestamp'2001-03-26 00:00:00', 1221.00);
insert into outcome_o (point, pdate, out) values(1, timestamp'2001-03-28 00:00:00', 2075.00);
insert into outcome_o (point, pdate, out) values(1, timestamp'2001-03-29 00:00:00', 2004.00);
insert into outcome_o (point, pdate, out) values(1, timestamp'2001-04-11 00:00:00', 3195.04);
insert into outcome_o (point, pdate, out) values(1, timestamp'2001-04-13 00:00:00', 4490.00);
insert into outcome_o (point, pdate, out) values(1, timestamp'2001-04-27 00:00:00', 3110.00);
insert into outcome_o (point, pdate, out) values(1, timestamp'2001-05-11 00:00:00', 2530.00);
insert into outcome_o (point, pdate, out) values(2, timestamp'2001-03-22 00:00:00', 1440.00);
insert into outcome_o (point, pdate, out) values(2, timestamp'2001-03-29 00:00:00', 7848.00);
insert into outcome_o (point, pdate, out) values(2, timestamp'2001-04-02 00:00:00', 2040.00);
insert into outcome_o (point, pdate, out) values(3, timestamp'2001-09-13 00:00:00', 1500.00);
insert into outcome_o (point, pdate, out) values(3, timestamp'2001-09-14 00:00:00', 2300.00);
insert into outcome_o (point, pdate, out) values(3, timestamp'2002-09-16 00:00:00', 2150.00);

insert into outcomes (ship, battle, result) values('Bismarck', 'North Atlantic', 'sunk');
insert into outcomes (ship, battle, result) values('California', 'Surigao Strait', 'OK');
insert into outcomes (ship, battle, result) values('Duke of York', 'North Cape', 'OK');
insert into outcomes (ship, battle, result) values('Fuso', 'Surigao Strait', 'sunk');
insert into outcomes (ship, battle, result) values('Hood', 'North Atlantic', 'sunk');
insert into outcomes (ship, battle, result) values('King George V', 'North Atlantic', 'OK');
insert into outcomes (ship, battle, result) values('Kirishima', 'Guadalcanal', 'sunk');
insert into outcomes (ship, battle, result) values('Prince of Wales', 'North Atlantic', 'damaged');
insert into outcomes (ship, battle, result) values('Rodney', 'North Atlantic', 'OK');
insert into outcomes (ship, battle, result) values('Schamhorst', 'North Cape', 'sunk');
insert into outcomes (ship, battle, result) values('South Dakota', 'Guadalcanal', 'damaged');
insert into outcomes (ship, battle, result) values('Tennessee', 'Surigao Strait', 'OK');
insert into outcomes (ship, battle, result) values('Washington', 'Guadalcanal', 'OK');
insert into outcomes (ship, battle, result) values('West Virginia', 'Surigao Strait', 'OK');
insert into outcomes (ship, battle, result) values('Yamashiro', 'Surigao Strait', 'sunk');
insert into outcomes (ship, battle, result) values('California', 'Guadalcanal', 'damaged');

insert into trip (trip_no, id_comp, plane, town_from, town_to, time_out, time_in) values(1100, 4, 'Boeing    ', 'Rostov                   ', 'Paris                    ', timestamp'1900-01-01 14:30:00', timestamp'1900-01-01 17:50:00');
insert into trip (trip_no, id_comp, plane, town_from, town_to, time_out, time_in) values(1101, 4, 'Boeing    ', 'Paris                    ', 'Rostov                   ', timestamp'1900-01-01 08:12:00', timestamp'1900-01-01 11:45:00');
insert into trip (trip_no, id_comp, plane, town_from, town_to, time_out, time_in) values(1123, 3, 'TU-154    ', 'Rostov                   ', 'Vladivostok              ', timestamp'1900-01-01 16:20:00', timestamp'1900-01-01 03:40:00');
insert into trip (trip_no, id_comp, plane, town_from, town_to, time_out, time_in) values(1124, 3, 'TU-154    ', 'Vladivostok              ', 'Rostov                   ', timestamp'1900-01-01 09:00:00', timestamp'1900-01-01 19:50:00');
insert into trip (trip_no, id_comp, plane, town_from, town_to, time_out, time_in) values(1145, 2, 'IL-86     ', 'Moscow                   ', 'Rostov                   ', timestamp'1900-01-01 09:35:00', timestamp'1900-01-01 11:23:00');
insert into trip (trip_no, id_comp, plane, town_from, town_to, time_out, time_in) values(1146, 2, 'IL-86     ', 'Rostov                   ', 'Moscow                   ', timestamp'1900-01-01 17:55:00', timestamp'1900-01-01 20:01:00');
insert into trip (trip_no, id_comp, plane, town_from, town_to, time_out, time_in) values(1181, 1, 'TU-134    ', 'Rostov                   ', 'Moscow                   ', timestamp'1900-01-01 06:12:00', timestamp'1900-01-01 08:01:00');
insert into trip (trip_no, id_comp, plane, town_from, town_to, time_out, time_in) values(1182, 1, 'TU-134    ', 'Moscow                   ', 'Rostov                   ', timestamp'1900-01-01 12:35:00', timestamp'1900-01-01 14:30:00');
insert into trip (trip_no, id_comp, plane, town_from, town_to, time_out, time_in) values(1187, 1, 'TU-134    ', 'Rostov                   ', 'Moscow                   ', timestamp'1900-01-01 15:42:00', timestamp'1900-01-01 17:39:00');
insert into trip (trip_no, id_comp, plane, town_from, town_to, time_out, time_in) values(1188, 1, 'TU-134    ', 'Moscow                   ', 'Rostov                   ', timestamp'1900-01-01 22:50:00', timestamp'1900-01-01 00:48:00');
insert into trip (trip_no, id_comp, plane, town_from, town_to, time_out, time_in) values(1195, 1, 'TU-154    ', 'Rostov                   ', 'Moscow                   ', timestamp'1900-01-01 23:30:00', timestamp'1900-01-01 01:11:00');
insert into trip (trip_no, id_comp, plane, town_from, town_to, time_out, time_in) values(1196, 1, 'TU-154    ', 'Moscow                   ', 'Rostov                   ', timestamp'1900-01-01 04:00:00', timestamp'1900-01-01 05:45:00');
insert into trip (trip_no, id_comp, plane, town_from, town_to, time_out, time_in) values(7771, 5, 'Boeing    ', 'London                   ', 'Singapore                ', timestamp'1900-01-01 01:00:00', timestamp'1900-01-01 11:00:00');
insert into trip (trip_no, id_comp, plane, town_from, town_to, time_out, time_in) values(7772, 5, 'Boeing    ', 'Singapore                ', 'London                   ', timestamp'1900-01-01 12:00:00', timestamp'1900-01-01 02:00:00');
insert into trip (trip_no, id_comp, plane, town_from, town_to, time_out, time_in) values(7773, 5, 'Boeing    ', 'London                   ', 'Singapore                ', timestamp'1900-01-01 03:00:00', timestamp'1900-01-01 13:00:00');
insert into trip (trip_no, id_comp, plane, town_from, town_to, time_out, time_in) values(7774, 5, 'Boeing    ', 'Singapore                ', 'London                   ', timestamp'1900-01-01 14:00:00', timestamp'1900-01-01 06:00:00');
insert into trip (trip_no, id_comp, plane, town_from, town_to, time_out, time_in) values(7775, 5, 'Boeing    ', 'London                   ', 'Singapore                ', timestamp'1900-01-01 09:00:00', timestamp'1900-01-01 20:00:00');
insert into trip (trip_no, id_comp, plane, town_from, town_to, time_out, time_in) values(7776, 5, 'Boeing    ', 'Singapore                ', 'London                   ', timestamp'1900-01-01 18:00:00', timestamp'1900-01-01 08:00:00');
insert into trip (trip_no, id_comp, plane, town_from, town_to, time_out, time_in) values(7777, 5, 'Boeing    ', 'London                   ', 'Singapore                ', timestamp'1900-01-01 18:00:00', timestamp'1900-01-01 06:00:00');
insert into trip (trip_no, id_comp, plane, town_from, town_to, time_out, time_in) values(7778, 5, 'Boeing    ', 'Singapore                ', 'London                   ', timestamp'1900-01-01 22:00:00', timestamp'1900-01-01 12:00:00');
insert into trip (trip_no, id_comp, plane, town_from, town_to, time_out, time_in) values(8881, 5, 'Boeing    ', 'London                   ', 'Paris                    ', timestamp'1900-01-01 03:00:00', timestamp'1900-01-01 04:00:00');
insert into trip (trip_no, id_comp, plane, town_from, town_to, time_out, time_in) values(8882, 5, 'Boeing    ', 'Paris                    ', 'London                   ', timestamp'1900-01-01 22:00:00', timestamp'1900-01-01 23:00:00');

insert into passenger (id_psg, name) values(1, 'Bruce Willis        ');
insert into passenger (id_psg, name) values(2, 'George Clooney      ');
insert into passenger (id_psg, name) values(3, 'Kevin Costner       ');
insert into passenger (id_psg, name) values(4, 'Donald Sutherland   ');
insert into passenger (id_psg, name) values(5, 'Jennifer Lopez      ');
insert into passenger (id_psg, name) values(6, 'Ray Liotta          ');
insert into passenger (id_psg, name) values(7, 'Samuel L. Jackson   ');
insert into passenger (id_psg, name) values(8, 'Nikole Kidman       ');
insert into passenger (id_psg, name) values(9, 'Alan Rickman        ');
insert into passenger (id_psg, name) values(10, 'Kurt Russell        ');
insert into passenger (id_psg, name) values(11, 'Harrison Ford       ');
insert into passenger (id_psg, name) values(12, 'Russell Crowe       ');
insert into passenger (id_psg, name) values(13, 'Steve Martin        ');
insert into passenger (id_psg, name) values(14, 'Michael Caine       ');
insert into passenger (id_psg, name) values(15, 'Angelina Jolie      ');
insert into passenger (id_psg, name) values(16, 'Mel Gibson          ');
insert into passenger (id_psg, name) values(17, 'Michael Douglas     ');
insert into passenger (id_psg, name) values(18, 'John Travolta       ');
insert into passenger (id_psg, name) values(19, 'Sylvester Stallone  ');
insert into passenger (id_psg, name) values(20, 'Tommy Lee Jones     ');
insert into passenger (id_psg, name) values(21, 'Catherine Zeta-Jones');
insert into passenger (id_psg, name) values(22, 'Antonio Banderas    ');
insert into passenger (id_psg, name) values(23, 'Kim Basinger        ');
insert into passenger (id_psg, name) values(24, 'Sam Neill           ');
insert into passenger (id_psg, name) values(25, 'Gary Oldman         ');
insert into passenger (id_psg, name) values(26, 'Clint Eastwood      ');
insert into passenger (id_psg, name) values(27, 'Brad Pitt           ');
insert into passenger (id_psg, name) values(28, 'Johnny Depp         ');
insert into passenger (id_psg, name) values(29, 'Pierce Brosnan      ');
insert into passenger (id_psg, name) values(30, 'Sean Connery        ');
insert into passenger (id_psg, name) values(31, 'Bruce Willis        ');
insert into passenger (id_psg, name) values(37, 'Mullah Omar         ');

insert into pass_in_trip (trip_no, pdate, id_psg, place) values(1100, timestamp'2003-04-29 00:00:00', 1, '1a        ');
insert into pass_in_trip (trip_no, pdate, id_psg, place) values(1123, timestamp'2003-04-05 00:00:00', 3, '2a        ');
insert into pass_in_trip (trip_no, pdate, id_psg, place) values(1123, timestamp'2003-04-08 00:00:00', 1, '4c        ');
insert into pass_in_trip (trip_no, pdate, id_psg, place) values(1123, timestamp'2003-04-08 00:00:00', 6, '4b        ');
insert into pass_in_trip (trip_no, pdate, id_psg, place) values(1124, timestamp'2003-04-02 00:00:00', 2, '2d        ');
insert into pass_in_trip (trip_no, pdate, id_psg, place) values(1145, timestamp'2003-04-05 00:00:00', 3, '2c        ');
insert into pass_in_trip (trip_no, pdate, id_psg, place) values(1181, timestamp'2003-04-01 00:00:00', 1, '1a        ');
insert into pass_in_trip (trip_no, pdate, id_psg, place) values(1181, timestamp'2003-04-01 00:00:00', 6, '1b        ');
insert into pass_in_trip (trip_no, pdate, id_psg, place) values(1181, timestamp'2003-04-01 00:00:00', 8, '3c        ');
insert into pass_in_trip (trip_no, pdate, id_psg, place) values(1181, timestamp'2003-04-13 00:00:00', 5, '1b        ');
insert into pass_in_trip (trip_no, pdate, id_psg, place) values(1182, timestamp'2003-04-13 00:00:00', 5, '4b        ');
insert into pass_in_trip (trip_no, pdate, id_psg, place) values(1187, timestamp'2003-04-14 00:00:00', 8, '3a        ');
insert into pass_in_trip (trip_no, pdate, id_psg, place) values(1188, timestamp'2003-04-01 00:00:00', 8, '3a        ');
insert into pass_in_trip (trip_no, pdate, id_psg, place) values(1182, timestamp'2003-04-13 00:00:00', 9, '6d        ');
insert into pass_in_trip (trip_no, pdate, id_psg, place) values(1145, timestamp'2003-04-25 00:00:00', 5, '1d        ');
insert into pass_in_trip (trip_no, pdate, id_psg, place) values(1187, timestamp'2003-04-14 00:00:00', 10, '3d        ');
insert into pass_in_trip (trip_no, pdate, id_psg, place) values(8882, timestamp'2005-11-06 00:00:00', 37, '1a        ');
insert into pass_in_trip (trip_no, pdate, id_psg, place) values(7771, timestamp'2005-11-07 00:00:00', 37, '1c        ');
insert into pass_in_trip (trip_no, pdate, id_psg, place) values(7772, timestamp'2005-11-07 00:00:00', 37, '1a        ');
insert into pass_in_trip (trip_no, pdate, id_psg, place) values(8881, timestamp'2005-11-08 00:00:00', 37, '1d        ');
insert into pass_in_trip (trip_no, pdate, id_psg, place) values(7778, timestamp'2005-11-05 00:00:00', 10, '2a        ');
insert into pass_in_trip (trip_no, pdate, id_psg, place) values(7772, timestamp'2005-11-29 00:00:00', 10, '3a        ');
insert into pass_in_trip (trip_no, pdate, id_psg, place) values(7771, timestamp'2005-11-04 00:00:00', 11, '4a        ');
insert into pass_in_trip (trip_no, pdate, id_psg, place) values(7771, timestamp'2005-11-07 00:00:00', 11, '1b        ');
insert into pass_in_trip (trip_no, pdate, id_psg, place) values(7771, timestamp'2005-11-09 00:00:00', 11, '5a        ');
insert into pass_in_trip (trip_no, pdate, id_psg, place) values(7772, timestamp'2005-11-07 00:00:00', 12, '1d        ');
insert into pass_in_trip (trip_no, pdate, id_psg, place) values(7773, timestamp'2005-11-07 00:00:00', 13, '2d        ');
insert into pass_in_trip (trip_no, pdate, id_psg, place) values(7772, timestamp'2005-11-29 00:00:00', 13, '1b        ');
insert into pass_in_trip (trip_no, pdate, id_psg, place) values(8882, timestamp'2005-11-13 00:00:00', 14, '3d        ');
insert into pass_in_trip (trip_no, pdate, id_psg, place) values(7771, timestamp'2005-11-14 00:00:00', 14, '4d        ');
insert into pass_in_trip (trip_no, pdate, id_psg, place) values(7771, timestamp'2005-11-16 00:00:00', 14, '5d        ');
insert into pass_in_trip (trip_no, pdate, id_psg, place) values(7772, timestamp'2005-11-29 00:00:00', 14, '1c        ');


insert into pc (code, model, speed, ram, hd, cd, price) values(1, '1232', 500, 64, 5, '12x', 600.00);
insert into pc (code, model, speed, ram, hd, cd, price) values(2, '1121', 750, 128, 14, '40x', 850.00);
insert into pc (code, model, speed, ram, hd, cd, price) values(3, '1233', 500, 64, 5, '12x', 600.00);
insert into pc (code, model, speed, ram, hd, cd, price) values(4, '1121', 600, 128, 14, '40x', 850.00);
insert into pc (code, model, speed, ram, hd, cd, price) values(5, '1121', 600, 128, 8, '40x', 850.00);
insert into pc (code, model, speed, ram, hd, cd, price) values(6, '1233', 750, 128, 20, '50x', 950.00);
insert into pc (code, model, speed, ram, hd, cd, price) values(7, '1232', 500, 32, 10, '12x', 400.00);
insert into pc (code, model, speed, ram, hd, cd, price) values(8, '1232', 450, 64, 8, '24x', 350.00);
insert into pc (code, model, speed, ram, hd, cd, price) values(9, '1232', 450, 32, 10, '24x', 350.00);
insert into pc (code, model, speed, ram, hd, cd, price) values(10, '1260', 500, 32, 10, '12x', 350.00);
insert into pc (code, model, speed, ram, hd, cd, price) values(11, '1233', 900, 128, 40, '40x', 980.00);
insert into pc (code, model, speed, ram, hd, cd, price) values(12, '1233', 800, 128, 20, '50x', 970.00);

insert into printer (code, model, color, type, price) values(1, '1276', 'n', 'Laser', 400.00);
insert into printer (code, model, color, type, price) values(2, '1433', 'y', 'Jet', 270.00);
insert into printer (code, model, color, type, price) values(3, '1434', 'y', 'Jet', 290.00);
insert into printer (code, model, color, type, price) values(4, '1401', 'n', 'Matrix', 150.00);
insert into printer (code, model, color, type, price) values(5, '1408', 'n', 'Matrix', 270.00);
insert into printer (code, model, color, type, price) values(6, '1288', 'n', 'Laser', 400.00);


insert into ships (name, class, launched) values('California', 'Tennessee', 1921);
insert into ships (name, class, launched) values('Haruna', 'Kongo', 1916);
insert into ships (name, class, launched) values('Hiei', 'Kongo', 1914);
insert into ships (name, class, launched) values('Iowa', 'Iowa', 1943);
insert into ships (name, class, launched) values('Kirishima', 'Kongo', 1915);
insert into ships (name, class, launched) values('Kongo', 'Kongo', 1913);
insert into ships (name, class, launched) values('Missouri', 'Iowa', 1944);
insert into ships (name, class, launched) values('Musashi', 'Yamato', 1942);
insert into ships (name, class, launched) values('New Jersey', 'Iowa', 1943);
insert into ships (name, class, launched) values('North Carolina', 'North Carolina', 1941);
insert into ships (name, class, launched) values('Ramillies', 'Revenge', 1917);
insert into ships (name, class, launched) values('Renown', 'Renown', 1916);
insert into ships (name, class, launched) values('Repulse', 'Renown', 1916);
insert into ships (name, class, launched) values('Resolution', 'Renown', 1916);
insert into ships (name, class, launched) values('Revenge', 'Revenge', 1916);
insert into ships (name, class, launched) values('Royal Oak', 'Revenge', 1916);
insert into ships (name, class, launched) values('Royal Sovereign', 'Revenge', 1916);
insert into ships (name, class, launched) values('Tennessee', 'Tennessee', 1920);
insert into ships (name, class, launched) values('Washington', 'North Carolina', 1941);
insert into ships (name, class, launched) values('Wisconsin', 'Iowa', 1944);
insert into ships (name, class, launched) values('Yamato', 'Yamato', 1941);
insert into ships (name, class, launched) values('South Dakota', 'North Carolina', 1941);


insert into utq (q_id, q_name) values(1, 'Square # 01');
insert into utq (q_id, q_name) values(2, 'Square # 02');
insert into utq (q_id, q_name) values(3, 'Square # 03');
insert into utq (q_id, q_name) values(4, 'Square # 04');
insert into utq (q_id, q_name) values(5, 'Square # 05');
insert into utq (q_id, q_name) values(6, 'Square # 06');
insert into utq (q_id, q_name) values(7, 'Square # 07');
insert into utq (q_id, q_name) values(8, 'Square # 08');
insert into utq (q_id, q_name) values(9, 'Square # 09');
insert into utq (q_id, q_name) values(10, 'Square # 10');
insert into utq (q_id, q_name) values(11, 'Square # 11');
insert into utq (q_id, q_name) values(12, 'Square # 12');
insert into utq (q_id, q_name) values(13, 'Square # 13');
insert into utq (q_id, q_name) values(14, 'Square # 14');
insert into utq (q_id, q_name) values(15, 'Square # 15');
insert into utq (q_id, q_name) values(16, 'Square # 16');
insert into utq (q_id, q_name) values(17, 'Square # 17');
insert into utq (q_id, q_name) values(18, 'Square # 18');
insert into utq (q_id, q_name) values(19, 'Square # 19');
insert into utq (q_id, q_name) values(20, 'Square # 20');
insert into utq (q_id, q_name) values(21, 'Square # 21');
insert into utq (q_id, q_name) values(22, 'Square # 22');
insert into utq (q_id, q_name) values(23, 'Square # 23');
insert into utq (q_id, q_name) values(25, 'Square # 25');

insert into utv (v_id, v_name, v_color) values(1, 'Balloon # 01', 'R');
insert into utv (v_id, v_name, v_color) values(2, 'Balloon # 02', 'R');
insert into utv (v_id, v_name, v_color) values(3, 'Balloon # 03', 'R');
insert into utv (v_id, v_name, v_color) values(4, 'Balloon # 04', 'G');
insert into utv (v_id, v_name, v_color) values(5, 'Balloon # 05', 'G');
insert into utv (v_id, v_name, v_color) values(6, 'Balloon # 06', 'G');
insert into utv (v_id, v_name, v_color) values(7, 'Balloon # 07', 'B');
insert into utv (v_id, v_name, v_color) values(8, 'Balloon # 08', 'B');
insert into utv (v_id, v_name, v_color) values(9, 'Balloon # 09', 'B');
insert into utv (v_id, v_name, v_color) values(10, 'Balloon # 10', 'R');
insert into utv (v_id, v_name, v_color) values(11, 'Balloon # 11', 'R');
insert into utv (v_id, v_name, v_color) values(12, 'Balloon # 12', 'R');
insert into utv (v_id, v_name, v_color) values(13, 'Balloon # 13', 'G');
insert into utv (v_id, v_name, v_color) values(14, 'Balloon # 14', 'G');
insert into utv (v_id, v_name, v_color) values(15, 'Balloon # 15', 'B');
insert into utv (v_id, v_name, v_color) values(16, 'Balloon # 16', 'B');
insert into utv (v_id, v_name, v_color) values(17, 'Balloon # 17', 'R');
insert into utv (v_id, v_name, v_color) values(18, 'Balloon # 18', 'G');
insert into utv (v_id, v_name, v_color) values(19, 'Balloon # 19', 'B');
insert into utv (v_id, v_name, v_color) values(20, 'Balloon # 20', 'R');
insert into utv (v_id, v_name, v_color) values(21, 'Balloon # 21', 'G');
insert into utv (v_id, v_name, v_color) values(22, 'Balloon # 22', 'B');
insert into utv (v_id, v_name, v_color) values(23, 'Balloon # 23', 'R');
insert into utv (v_id, v_name, v_color) values(24, 'Balloon # 24', 'G');
insert into utv (v_id, v_name, v_color) values(25, 'Balloon # 25', 'B');
insert into utv (v_id, v_name, v_color) values(26, 'Balloon # 26', 'B');
insert into utv (v_id, v_name, v_color) values(27, 'Balloon # 27', 'R');
insert into utv (v_id, v_name, v_color) values(28, 'Balloon # 28', 'G');
insert into utv (v_id, v_name, v_color) values(29, 'Balloon # 29', 'R');
insert into utv (v_id, v_name, v_color) values(30, 'Balloon # 30', 'G');
insert into utv (v_id, v_name, v_color) values(31, 'Balloon # 31', 'R');
insert into utv (v_id, v_name, v_color) values(32, 'Balloon # 32', 'G');
insert into utv (v_id, v_name, v_color) values(33, 'Balloon # 33', 'B');
insert into utv (v_id, v_name, v_color) values(34, 'Balloon # 34', 'R');
insert into utv (v_id, v_name, v_color) values(35, 'Balloon # 35', 'G');
insert into utv (v_id, v_name, v_color) values(36, 'Balloon # 36', 'B');
insert into utv (v_id, v_name, v_color) values(37, 'Balloon # 37', 'R');
insert into utv (v_id, v_name, v_color) values(38, 'Balloon # 38', 'G');
insert into utv (v_id, v_name, v_color) values(39, 'Balloon # 39', 'B');
insert into utv (v_id, v_name, v_color) values(40, 'Balloon # 40', 'R');
insert into utv (v_id, v_name, v_color) values(41, 'Balloon # 41', 'R');
insert into utv (v_id, v_name, v_color) values(42, 'Balloon # 42', 'G');
insert into utv (v_id, v_name, v_color) values(43, 'Balloon # 43', 'B');
insert into utv (v_id, v_name, v_color) values(44, 'Balloon # 44', 'R');
insert into utv (v_id, v_name, v_color) values(45, 'Balloon # 45', 'G');
insert into utv (v_id, v_name, v_color) values(46, 'Balloon # 46', 'B');
insert into utv (v_id, v_name, v_color) values(47, 'Balloon # 47', 'B');
insert into utv (v_id, v_name, v_color) values(48, 'Balloon # 48', 'G');
insert into utv (v_id, v_name, v_color) values(49, 'Balloon # 49', 'R');
insert into utv (v_id, v_name, v_color) values(50, 'Balloon # 50', 'G');
insert into utv (v_id, v_name, v_color) values(51, 'Balloon # 51', 'B');
insert into utv (v_id, v_name, v_color) values(52, 'Balloon # 52', 'R');
insert into utv (v_id, v_name, v_color) values(53, 'Balloon # 53', 'G');
insert into utv (v_id, v_name, v_color) values(54, 'Balloon # 54', 'B');

insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:12:01', 1, 1, 155);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-06-23 01:12:02', 1, 1, 100);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:12:03', 2, 2, 255);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:12:04', 3, 3, 255);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:12:05', 1, 4, 255);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:12:06', 2, 5, 255);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:12:07', 3, 6, 255);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:12:08', 1, 7, 255);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:12:09', 2, 8, 255);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:12:10', 3, 9, 255);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:12:11', 4, 10, 50);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:12:12', 5, 11, 100);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:12:13', 5, 12, 155);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:12:14', 5, 13, 155);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:12:15', 5, 14, 100);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:12:16', 5, 15, 50);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:12:17', 5, 16, 205);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:12:18', 6, 10, 155);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:12:19', 6, 17, 100);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:12:20', 6, 18, 255);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:12:21', 6, 19, 255);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:12:22', 7, 17, 155);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:12:23', 7, 20, 100);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:12:24', 7, 21, 255);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:12:25', 7, 22, 255);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:12:26', 8, 10, 50);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:12:27', 9, 23, 255);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:12:28', 9, 24, 255);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:12:29', 9, 25, 100);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:12:30', 9, 26, 155);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:12:31', 10, 25, 155);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:12:31', 10, 26, 100);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:12:33', 10, 27, 10);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:12:34', 10, 28, 10);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:12:35', 10, 29, 245);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:12:36', 10, 30, 245);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:12:37', 11, 31, 100);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:12:38', 11, 32, 100);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:12:39', 11, 33, 100);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:12:40', 11, 34, 155);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:12:41', 11, 35, 155);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:12:42', 11, 36, 155);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:12:43', 12, 31, 155);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:12:44', 12, 32, 155);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:12:45', 12, 33, 155);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:12:46', 12, 34, 100);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:12:47', 12, 35, 100);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:12:48', 12, 36, 100);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:13:01', 4, 37, 20);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:13:02', 8, 38, 20);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:13:03', 13, 39, 123);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:13:04', 14, 39, 111);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:13:05', 14, 40, 50);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:13:06', 15, 41, 50);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:13:07', 15, 41, 50);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:13:08', 15, 42, 50);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:13:09', 15, 42, 50);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:13:10', 16, 42, 50);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:13:11', 16, 42, 50);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:13:12', 16, 43, 50);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:13:13', 16, 43, 50);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:13:14', 16, 47, 50);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:13:15', 17, 44, 10);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:13:16', 17, 44, 10);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:13:17', 17, 45, 10);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:13:18', 17, 45, 10);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-02-01 01:13:19', 18, 45, 10);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-03-01 01:13:20', 18, 45, 10);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-04-01 01:13:21', 18, 46, 10);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-05-01 01:13:22', 18, 46, 10);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-06-11 01:13:23', 19, 44, 10);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:13:24', 19, 44, 10);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:13:25', 19, 45, 10);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:13:26', 19, 45, 10);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-02-01 01:13:27', 20, 45, 10);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-03-01 01:13:28', 20, 45, 10);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-04-01 01:13:29', 20, 46, 10);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-05-01 01:13:30', 20, 46, 10);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-02-01 01:13:31', 21, 49, 50);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-02-02 01:13:32', 21, 49, 50);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-02-03 01:13:33', 21, 50, 50);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-02-04 01:13:34', 21, 50, 50);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-02-05 01:13:35', 21, 48, 1);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2000-01-01 01:13:36', 22, 50, 50);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2001-01-01 01:13:37', 22, 50, 50);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2002-01-01 01:13:38', 22, 51, 50);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2002-06-01 01:13:39', 22, 51, 50);
insert into utb (b_datetime, b_q_id, b_v_id, b_vol) values(timestamp'2003-01-01 01:13:05', 4, 37, 185);

commit;

