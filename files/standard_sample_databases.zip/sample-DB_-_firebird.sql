set bail on;
--NB: make connection with charset = utf8!
--set names utf8;
--shell del c:\temp\tmp4test.fdb 2>nul;
--create database 'localhost:c:\temp\tmp4test.fdb' user 'sysdba' password 'masterkey' default character set utf8;

create collation ci_coll for utf8 from unicode case insensitive;
commit;

set term ^;
execute block as
begin
    if ( cast(left(rdb$get_context('SYSTEM','ENGINE_VERSION'),2) as int) >= 6 ) then
        execute statement 'alter character set utf8 set default collation PUBLIC.ci_coll';
    else
        execute statement 'alter character set utf8 set default collation ci_coll';
end
^
set term ;^
commit;

create generator cust_no_gen start with 1;
create generator emp_no_gen start with 1;

-- ##########################
-- ###    D O M A I N S   ###
-- ##########################


create domain addressline as varchar(30);
create domain budget as decimal(12, 2)
         default 50000;
create domain countryname as varchar(15);
create domain custno as integer;
create domain deptno as char(3);
create domain empno as smallint;
create domain firstname as varchar(15);
create domain jobcode as varchar(5);
create domain jobgrade as smallint;
create domain lastname as varchar(20);
create domain phonenumber as varchar(20);
create domain ponumber as char(8);
create domain prodtype as varchar(12)
         default 'software' not null;
create domain projno as char(5);
create domain salary as numeric(10, 2)
         default 0;
commit;

-- ########################
-- ###    T A B L E S   ###
-- ########################

create table country (
    country countryname not null
   ,currency varchar(10) not null
   ,constraint country_pk primary key(country)
);


create table customer (
    cust_no custno not null
   ,customer varchar(25) not null
   ,contact_first firstname
   ,contact_last lastname
   ,phone_no phonenumber
   ,address_line1 addressline
   ,address_line2 addressline
   ,city varchar(25)
   ,state_province varchar(15)
   ,country countryname
   ,postal_code varchar(12)
   ,on_hold char(1) default null
   ,constraint customer_pk primary key(cust_no)
);


create table department (
    dept_no deptno not null
   ,department varchar(25) not null
   ,head_dept deptno
   ,mngr_no empno
   ,budget budget
   ,location varchar(15)
   ,phone_no phonenumber default '555-1234'
   ,constraint department_pk primary key (dept_no)
   ,constraint department_puk unique (department)
);

create table employee (
    emp_no empno not null
   ,first_name firstname not null
   ,last_name lastname not null
   ,phone_ext varchar(4)
   ,hire_date timestamp default 'now' not null
   ,dept_no deptno not null
   ,job_code jobcode not null
   ,job_grade jobgrade not null
   ,job_country countryname not null
   ,salary salary not null
   ,full_name varchar(37) computed by (null)
   ,constraint employee_pk primary key (emp_no)
);


create table employee_project (
    emp_no empno not null
   ,proj_id projno not null
   ,constraint emp_proj_pk primary key (emp_no, proj_id)
);


create table job (
    job_code jobcode not null
   ,job_grade jobgrade not null
   ,job_country countryname not null
   ,job_title varchar(25) not null
   ,min_salary salary not null
   ,max_salary salary not null
   ,job_requirement blob sub_type text segment size 400
   ,language_req varchar(15)[5]
   ,constraint job_pk primary key (job_code, job_grade, job_country)
);


create table project (
    proj_id projno not null
   ,proj_name varchar(20) not null
   ,proj_desc blob sub_type text segment size 800
   ,team_leader empno
   ,product prodtype
   ,constraint project_pk primary key (proj_id)
   ,constraint project_uk unique (proj_name)
);


create table proj_dept_budget (
    fiscal_year integer not null
   ,proj_id projno not null
   ,dept_no deptno not null
   ,quart_head_cnt integer[4]
   ,projected_budget budget
   ,constraint proj_dept_budget_pk primary key (fiscal_year, proj_id, dept_no)
);


create table salary_history (
    emp_no empno not null
   ,change_date timestamp default 'now' not null
   ,updater_id varchar(20) not null
   ,old_salary salary not null
   ,percent_change double precision default 0 not null
   ,new_salary double precision computed by (null)
   ,constraint sal_hist_pk primary key (emp_no, change_date, updater_id)
);

create table sales (
    po_number ponumber not null
   ,cust_no custno not null
   ,sales_rep empno
   ,order_status varchar(7) default 'new' not null
   ,order_date timestamp default 'now' not null
   ,ship_date timestamp
   ,date_needed timestamp
   ,paid char(1) default 'n'
   ,qty_ordered integer default 1 not null
   ,total_value decimal(9, 2) not null
   ,discount float default 0 not null
   ,item_type prodtype
   ,aged numeric(18, 9) computed by (null)
   ,constraint sales_pk primary key (po_number)
);
commit;

-- #####################################
-- ###    P R O C    H E A D E R S   ###
-- #####################################

set autoddl off;
set term ^;
create or alter procedure add_emp_proj (emp_no smallint, proj_id char(5)) as 
begin exit; end
^
create or alter procedure all_langs returns (code varchar(5), grade varchar(5), country varchar(15), lang varchar(15)) as 
begin suspend; end
^
create or alter procedure delete_employee (emp_num integer) as 
begin exit; end
^
create or alter procedure dept_budget (dno char(3)) returns (tot decimal(12, 2)) as 
begin suspend; end
^
create or alter procedure get_emp_proj (emp_no smallint) returns (proj_id char(5)) as 
begin suspend; end 
^
create or alter procedure mail_label (cust_no integer)
returns (
    line1 char(40),
    line2 char(40),
    line3 char(40),
    line4 char(40),
    line5 char(40),
    line6 char(40))
as 
begin suspend; end
^
create or alter procedure org_chart
returns (
    head_dept char(25),
    department char(25),
    mngr_name char(20),
    title char(5),
    emp_cnt integer)
as 
begin suspend; end
^
create or alter procedure ship_order (po_num char(8)) as 
begin exit; end
^
create or alter procedure show_langs (code varchar(5), grade smallint, cty varchar(15)) returns (languages varchar(15)) as 
begin suspend; end
^
create or alter procedure sub_tot_budget (head_dept char(3))
returns (
    tot_budget decimal(12, 2),
    avg_budget decimal(12, 2),
    min_budget decimal(12, 2),
    max_budget decimal(12, 2)
) as 
begin suspend; end
^
set term ;^
commit;
set autoddl on;

-- ######################
-- ###    V I E W S   ###
-- ######################

create view phone_list (emp_no, first_name, last_name, phone_ext, location, phone_no) as
select
    emp_no, first_name, last_name, phone_ext, location, phone_no
    from employee, department
    where employee.dept_no = department.dept_no
;

-- ################################
-- ###    E X C E P T I O N S   ###
-- ################################

create exception customer_check 'overdue balance -- can not ship.';
create exception customer_on_hold 'this customer is on hold.';
create exception order_already_shipped 'order status is "shipped."';
create exception reassign_sales 'reassign the sales records before deleting this employee.';
create exception unknown_emp_id 'invalid employee number or project id.';
commit;

-- ##########################################
-- ###   P R O C E D U R E S    B O D Y   ###
-- ##########################################

set autoddl off;
set term ^;
alter procedure add_emp_proj (emp_no smallint, proj_id char(5)) as 
begin
    begin
    insert into employee_project (emp_no, proj_id) values (:emp_no, :proj_id);
    when sqlcode -530 do
        exception unknown_emp_id;
    end
end
^

alter procedure all_langs returns (code varchar(5), grade varchar(5), country varchar(15), lang varchar(15)) as 
begin
    for select job_code, job_grade, job_country from job
        into :code, :grade, :country
    do
    begin
        for
            select languages from show_langs (:code, :grade, :country) into :lang
        do
            suspend;
        /* put nice separators between rows */
        code = '=====';
        grade = '=====';
        country = '===============';
        lang = '==============';
        suspend;
    end
end
^

alter procedure delete_employee (emp_num integer)
as 
    declare any_sales integer;
begin
    any_sales = 0;

    /*
     *    if there are any sales records referencing this employee,
     *    can't delete the employee until the sales are re-assigned
     *    to another employee or changed to null.
     */
    select count(po_number)
    from sales
    where sales_rep = :emp_num
    into :any_sales;

    if (any_sales > 0) then
    begin
        exception reassign_sales;
    end

    /*
     *    if the employee is a manager, update the department.
     */
    update department
    set mngr_no = null
    where mngr_no = :emp_num;

    /*
     *    if the employee is a project leader, update project.
     */
    update project
    set team_leader = null
    where team_leader = :emp_num;

    /*
     *    delete the employee from any projects.
     */
    delete from employee_project
    where emp_no = :emp_num;

    /*
     *    delete old salary records.
     */
    delete from salary_history
    where emp_no = :emp_num;

    /*
     *    delete the employee.
     */
    delete from employee
    where emp_no = :emp_num;
end
^

alter procedure dept_budget (dno char(3)) returns (tot decimal(12, 2))
as 
    declare sumb decimal(12, 2);
    declare rdno char(3);
    declare cnt integer;
begin
    tot = 0;

    select budget from department where dept_no = :dno into :tot;

    select count(budget) from department where head_dept = :dno into :cnt;

    if (cnt = 0) then
        suspend;

    for select dept_no
        from department
        where head_dept = :dno
        into :rdno
    do
        begin
            execute procedure dept_budget :rdno returning_values :sumb;
            tot = tot + sumb;
        end

    suspend;
end ^

alter procedure get_emp_proj (emp_no smallint) returns (proj_id char(5))
as 
begin
    for select proj_id
        from employee_project
        where emp_no = :emp_no
        into :proj_id
    do
        suspend;
end ^

alter procedure mail_label (cust_no integer)
returns (
    line1 char(40),
    line2 char(40),
    line3 char(40),
    line4 char(40),
    line5 char(40),
    line6 char(40)
) as 
    declare customer    varchar(25);
    declare first_name        varchar(15);
    declare last_name        varchar(20);
    declare addr1        varchar(30);
    declare addr2        varchar(30);
    declare city        varchar(25);
    declare state        varchar(15);
    declare country    varchar(15);
    declare postcode    varchar(12);
    declare cnt        integer;
begin
    line1 = '';
    line2 = '';
    line3 = '';
    line4 = '';
    line5 = '';
    line6 = '';

    select customer, contact_first, contact_last, address_line1,
        address_line2, city, state_province, country, postal_code
    from customer
    where cust_no = :cust_no
    into :customer, :first_name, :last_name, :addr1, :addr2,
        :city, :state, :country, :postcode;

    if (customer is not null) then
        line1 = customer;
    if (first_name is not null) then
        line2 = first_name || ' ' || last_name;
    else
        line2 = last_name;
    if (addr1 is not null) then
        line3 = addr1;
    if (addr2 is not null) then
        line4 = addr2;

    if (country = 'usa') then
    begin
        if (city is not null) then
            line5 = city || ', ' || state || '  ' || postcode;
        else
            line5 = state || '  ' || postcode;
    end
    else
    begin
        if (city is not null) then
            line5 = city || ', ' || state;
        else
            line5 = state;
        line6 = country || '    ' || postcode;
    end

    suspend;
end
^

alter procedure org_chart
returns (
    head_dept char(25),
    department char(25),
    mngr_name char(20),
    title char(5),
    emp_cnt integer
) as 
    declare mngr_no integer;
    declare dno char(3);
begin
    for select h.department, d.department, d.mngr_no, d.dept_no
        from department d
        left outer join department h on d.head_dept = h.dept_no
        order by d.dept_no
        into :head_dept, :department, :mngr_no, :dno
    do
    begin
        if (:mngr_no is null) then
            begin
                mngr_name = '--tbh--';
                title = '';
            end
        else
            select full_name, job_code
            from employee
            where emp_no = :mngr_no
            into :mngr_name, :title;

        select count(emp_no)
        from employee
        where dept_no = :dno
        into :emp_cnt;

        suspend;
    end
end
^

alter procedure ship_order (po_num char(8)) as 
    declare ord_stat char(7);
    declare hold_stat char(1);
    declare cust_no integer;
    declare any_po char(8);
begin
    select s.order_status, c.on_hold, c.cust_no
    from sales s, customer c
    where po_number = :po_num
    and s.cust_no = c.cust_no
    into :ord_stat, :hold_stat, :cust_no;

    /* this purchase order has been already shipped. */
    if (ord_stat = 'shipped') then
    begin
        exception order_already_shipped;
    end

    /*    customer is on hold. */
    else if (hold_stat = '*') then
    begin
        exception customer_on_hold;
    end

    /*
     *    if there is an unpaid balance on orders shipped over 2 months ago,
     *    put the customer on hold.
     */
    for select po_number
        from sales
        where cust_no = :cust_no
        and order_status = 'shipped'
        and paid = 'n'
        and ship_date < cast('now' as timestamp) - 60
        into :any_po
    do
    begin
        exception customer_check;
    end

    /*
     *    ship the order.
     */
    update sales
    set order_status = 'shipped', ship_date = 'now'
    where po_number = :po_num;
end
^

alter procedure show_langs (
    code varchar(5),
    grade smallint,
    cty varchar(15)
) returns (
    languages varchar(15)
) as 
    declare i integer;
begin
    i = 1;
    while (i <= 5) do
    begin
        select language_req[:i] from job
        where ((job_code = :code) and (job_grade = :grade) and (job_country = :cty)
               and (language_req is not null))
        into :languages;
        if (languages = ' ') then  /* prints 'null' instead of blanks */
             languages = 'null';
        i = i +1;
        suspend;
    end
end ^

alter procedure sub_tot_budget (head_dept char(3))
returns (
    tot_budget decimal(12, 2),
    avg_budget decimal(12, 2),
    min_budget decimal(12, 2),
    max_budget decimal(12, 2)
) as 
begin
    select sum(budget), avg(budget), min(budget), max(budget)
        from department
        where head_dept = :head_dept
        into :tot_budget, :avg_budget, :min_budget, :max_budget;
    suspend;
end ^

set term ;^
commit;
set autoddl on;

-- #############################################################
-- ###   D O M A I N    C H E C K    C O N S T R A I N T S   ###
-- #############################################################

alter domain budget add constraint
         check (value > 10000 and value <= 2000000);
alter domain custno add constraint
         check (value > 1000);
alter domain deptno add constraint
         check (value = '000' or (value > '0' and value <= '999') or value is null);
alter domain jobcode add constraint
         check (value > '99999');
alter domain jobgrade add constraint
         check (value between 0 and 6);
alter domain ponumber add constraint
         check (value starting with 'v');
alter domain prodtype add constraint
         check (value in ('software', 'hardware', 'other', 'n/a'));

-- disabled, otherwise:
-- Statement failed, SQLSTATE = 23000
-- validation error for column "EMPLOYEE_PROJECT"."PROJ_ID", value "mapdb"
-- alter domain projno add constraint
--         check (value = upper (value));

alter domain salary add constraint
         check (value > 0);

-- ############################################################
-- ###   T A B L E S    C H E C K   C O N S T R A I N T S   ###
-- ############################################################

alter table job add constraint job_chk_01
        check (min_salary < max_salary);

alter table employee add constraint employee_chk_01
        check ( salary >= (select min_salary from job where
                        job.job_code = employee.job_code and
                        job.job_grade = employee.job_grade and
                        job.job_country = employee.job_country) and
            salary <= (select max_salary from job where
                        job.job_code = employee.job_code and
                        job.job_grade = employee.job_grade and
                        job.job_country = employee.job_country));

alter table proj_dept_budget add constraint proj_dept_budget_chk_01
        check (fiscal_year >= 1993);

alter table salary_history add constraint salary_history_chk_01
        check (percent_change between -50 and 50);

alter table customer add constraint customer_chk_01
        check (on_hold is null or on_hold = '*');

alter table sales add constraint sales_chk_01
        check (order_status in
                            ('new', 'open', 'shipped', 'waiting'));

alter table sales add constraint sales_chk_02
        check (ship_date >= order_date or ship_date is null);

alter table sales add constraint sales_chk_03
        check (date_needed > order_date or date_needed is null);

alter table sales add constraint sales_chk_04
        check (paid in ('y', 'n'));

alter table sales add constraint sales_chk_05
        check (qty_ordered >= 1);

alter table sales add constraint sales_chk_06
        check (total_value >= 0);

alter table sales add constraint sales_chk_07
        check (discount >= 0 and discount <= 1);

alter table sales add constraint sales_chk_08
        check (not (order_status = 'shipped' and ship_date is null));


/**********************************
-- temp disabled, see #8525
alter table sales add constraint sales_chk_09
        check (not ( 
                       order_status = 'shipped' and
                       exists (
                           select on_hold from customer
                           where customer.cust_no = sales.cust_no
                           and customer.on_hold = '*'
                       )
                   )
              );
-- *********************************/


-- ############################################
-- ###   C O M P U T E D    C O L U M N S   ###
-- ############################################

alter table employee 
        alter full_name type varchar(37) computed by (last_name || ', ' || first_name);

alter table salary_history 
        alter new_salary type double precision computed by (old_salary + old_salary * percent_change / 100);

alter table sales 
        alter aged type numeric(18, 9) computed by (ship_date - order_date);

-- ########################
-- ### T R I G G E R S  ###
-- ########################
set term ^;
create trigger set_cust_no for customer active before insert position 0 
as
begin
    if (new.cust_no is null) then
    new.cust_no = gen_id(cust_no_gen, 1);
end
^

create trigger set_emp_no for employee active before insert position 0 
as
begin
    if (new.emp_no is null) then
    new.emp_no = gen_id(emp_no_gen, 1);
end
^

create trigger save_salary_change for employee active after update position 0 
as
begin
    if (old.salary <> new.salary) then
        insert into salary_history
            (emp_no, change_date, updater_id, old_salary, percent_change)
        values (
            old.emp_no,
            'now',
            user,
            old.salary,
            (new.salary - old.salary) * 100 / old.salary);
end
^

create trigger post_new_order for sales active after insert position 0 
as
begin
    post_event 'new_order';
end
^
set term ;^
commit;

-- ####################
-- ### G R A N T S  ###
-- ####################

grant all on country to public with grant option;
grant all on customer to public with grant option;
grant all on department to public with grant option;
grant all on employee to public with grant option;
grant all on employee_project to public with grant option;
grant all on job to public with grant option;
grant all on phone_list to public with grant option;
grant all on project to public with grant option;
grant all on proj_dept_budget to public with grant option;
grant all on salary_history to public with grant option;
grant all on sales to public with grant option;
grant execute on procedure add_emp_proj to public with grant option;
grant execute on procedure all_langs to public with grant option;
grant execute on procedure delete_employee to public with grant option;
grant execute on procedure dept_budget to public with grant option;
grant execute on procedure get_emp_proj to public with grant option;
grant execute on procedure mail_label to public with grant option;
grant execute on procedure org_chart to public with grant option;
grant execute on procedure ship_order to public with grant option;
grant execute on procedure show_langs to public with grant option;
grant execute on procedure sub_tot_budget to public with grant option;
commit;

-- ###################
-- ###   D A T A   ###
-- ###################


insert into country (country, currency) values ('australia', 'adollar');
insert into country (country, currency) values ('austria', 'euro');
insert into country (country, currency) values ('belgium', 'euro');
insert into country (country, currency) values ('canada', 'cdndlr');
insert into country (country, currency) values ('england', 'pound');
insert into country (country, currency) values ('fiji', 'fdollar');
insert into country (country, currency) values ('france', 'euro');
insert into country (country, currency) values ('germany', 'euro');
insert into country (country, currency) values ('hong kong', 'hkdollar');
insert into country (country, currency) values ('italy', 'euro');
insert into country (country, currency) values ('japan', 'yen');
insert into country (country, currency) values ('netherlands', 'euro');
insert into country (country, currency) values ('romania', 'rleu');
insert into country (country, currency) values ('russia', 'ruble');
insert into country (country, currency) values ('switzerland', 'sfranc');
insert into country (country, currency) values ('usa', 'dollar');


insert into customer (cust_no, customer, contact_first, contact_last, phone_no, address_line1, address_line2, city, state_province, country, postal_code, on_hold) values (1001, 'signature design', 'dale j.', 'little', '(619) 530-2710', '15500 pacific heights blvd.', null, 'san diego', 'ca', 'usa', '92121', null);
insert into customer (cust_no, customer, contact_first, contact_last, phone_no, address_line1, address_line2, city, state_province, country, postal_code, on_hold) values (1002, 'dallas technologies', 'glen', 'brown', '(214) 960-2233', 'p. o. box 47000', null, 'dallas', 'tx', 'usa', '75205', '*');
insert into customer (cust_no, customer, contact_first, contact_last, phone_no, address_line1, address_line2, city, state_province, country, postal_code, on_hold) values (1003, 'buttle, griffith and co.', 'james', 'buttle', '(617) 488-1864', '2300 newbury street', 'suite 101', 'boston', 'ma', 'usa', '02115', null);
insert into customer (cust_no, customer, contact_first, contact_last, phone_no, address_line1, address_line2, city, state_province, country, postal_code, on_hold) values (1004, 'central bank', 'elizabeth', 'brocket', '61 211 99 88', '66 lloyd street', null, 'manchester', null, 'england', 'm2 3la', null);
insert into customer (cust_no, customer, contact_first, contact_last, phone_no, address_line1, address_line2, city, state_province, country, postal_code, on_hold) values (1005, 'dt systems, ltd.', 'tai', 'wu', '(852) 850 43 98', '400 connaught road', null, 'central hong kong', null, 'hong kong', null, null);
insert into customer (cust_no, customer, contact_first, contact_last, phone_no, address_line1, address_line2, city, state_province, country, postal_code, on_hold) values (1006, 'dataserve international', 'tomas', 'bright', '(613) 229 3323', '2000 carling avenue', 'suite 150', 'ottawa', 'on', 'canada', 'k1v 9g1', null);
insert into customer (cust_no, customer, contact_first, contact_last, phone_no, address_line1, address_line2, city, state_province, country, postal_code, on_hold) values (1007, 'mrs. beauvais', null, 'mrs. beauvais', null, 'p.o. box 22743', null, 'pebble beach', 'ca', 'usa', '93953', null);
insert into customer (cust_no, customer, contact_first, contact_last, phone_no, address_line1, address_line2, city, state_province, country, postal_code, on_hold) values (1008, 'anini vacation rentals', 'leilani', 'briggs', '(808) 835-7605', '3320 lawai road', null, 'lihue', 'hi', 'usa', '96766', null);
insert into customer (cust_no, customer, contact_first, contact_last, phone_no, address_line1, address_line2, city, state_province, country, postal_code, on_hold) values (1009, 'max', 'max', null, '22 01 23', '1 emerald cove', null, 'turtle island', null, 'fiji', null, '*');
insert into customer (cust_no, customer, contact_first, contact_last, phone_no, address_line1, address_line2, city, state_province, country, postal_code, on_hold) values (1010, 'mpm corporation', 'miwako', 'miyamoto', '3 880 77 19', '2-64-7 sasazuka', null, 'tokyo', null, 'japan', '150', null);
insert into customer (cust_no, customer, contact_first, contact_last, phone_no, address_line1, address_line2, city, state_province, country, postal_code, on_hold) values (1011, 'dynamic intelligence corp', 'victor', 'granges', '01 221 16 50', 'florhofgasse 10', null, 'zurich', null, 'switzerland', '8005', null);
insert into customer (cust_no, customer, contact_first, contact_last, phone_no, address_line1, address_line2, city, state_province, country, postal_code, on_hold) values (1012, '3d-pad corp.', 'michelle', 'roche', '1 43 60 61', '22 place de la concorde', null, 'paris', null, 'france', '75008', null);
insert into customer (cust_no, customer, contact_first, contact_last, phone_no, address_line1, address_line2, city, state_province, country, postal_code, on_hold) values (1013, 'lorenzi export, ltd.', 'andreas', 'lorenzi', '02 404 6284', 'via eugenia, 15', null, 'milan', null, 'italy', '20124', null);
insert into customer (cust_no, customer, contact_first, contact_last, phone_no, address_line1, address_line2, city, state_province, country, postal_code, on_hold) values (1014, 'dyno consulting', 'greta', 'hessels', '02 500 5940', 'rue royale 350', null, 'brussels', null, 'belgium', '1210', null);
insert into customer (cust_no, customer, contact_first, contact_last, phone_no, address_line1, address_line2, city, state_province, country, postal_code, on_hold) values (1015, 'geotech inc.', 'k.m.', 'neppelenbroek', '(070) 44 91 18', 'p.0.box 702', null, 'den haag', null, 'netherlands', '2514', null);


insert into department (dept_no, department, head_dept, mngr_no, budget, location, phone_no) values ('000', 'corporate headquarters', null, 105, 1000000, 'monterey', '(408) 555-1234');
insert into department (dept_no, department, head_dept, mngr_no, budget, location, phone_no) values ('100', 'sales and marketing', '000', 85, 2000000, 'san francisco', '(415) 555-1234');
insert into department (dept_no, department, head_dept, mngr_no, budget, location, phone_no) values ('110', 'pacific rim headquarters', '100', 34, 600000, 'kuaui', '(808) 555-1234');
insert into department (dept_no, department, head_dept, mngr_no, budget, location, phone_no) values ('115', 'field office: japan', '110', 118, 500000, 'tokyo', '3 5350 0901');
insert into department (dept_no, department, head_dept, mngr_no, budget, location, phone_no) values ('116', 'field office: singapore', '110', null, 300000, 'singapore', '3 55 1234');
insert into department (dept_no, department, head_dept, mngr_no, budget, location, phone_no) values ('120', 'european headquarters', '100', 36, 700000, 'london', '71 235-4400');
insert into department (dept_no, department, head_dept, mngr_no, budget, location, phone_no) values ('121', 'field office: switzerland', '120', 141, 500000, 'zurich', '1 211 7767');
insert into department (dept_no, department, head_dept, mngr_no, budget, location, phone_no) values ('123', 'field office: france', '120', 134, 400000, 'cannes', '58 68 11 12');
insert into department (dept_no, department, head_dept, mngr_no, budget, location, phone_no) values ('125', 'field office: italy', '120', 121, 400000, 'milan', '2 430 39 39');
insert into department (dept_no, department, head_dept, mngr_no, budget, location, phone_no) values ('130', 'field office: east coast', '100', 11, 500000, 'boston', '(617) 555-1234');
insert into department (dept_no, department, head_dept, mngr_no, budget, location, phone_no) values ('140', 'field office: canada', '100', 72, 500000, 'toronto', '(416) 677-1000');
insert into department (dept_no, department, head_dept, mngr_no, budget, location, phone_no) values ('180', 'marketing', '100', null, 1500000, 'san francisco', '(415) 555-1234');
insert into department (dept_no, department, head_dept, mngr_no, budget, location, phone_no) values ('600', 'engineering', '000', 2, 1100000, 'monterey', '(408) 555-1234');
insert into department (dept_no, department, head_dept, mngr_no, budget, location, phone_no) values ('620', 'software products div.', '600', null, 1200000, 'monterey', '(408) 555-1234');
insert into department (dept_no, department, head_dept, mngr_no, budget, location, phone_no) values ('621', 'software development', '620', null, 400000, 'monterey', '(408) 555-1234');
insert into department (dept_no, department, head_dept, mngr_no, budget, location, phone_no) values ('622', 'quality assurance', '620', 9, 300000, 'monterey', '(408) 555-1234');
insert into department (dept_no, department, head_dept, mngr_no, budget, location, phone_no) values ('623', 'customer support', '620', 15, 650000, 'monterey', '(408) 555-1234');
insert into department (dept_no, department, head_dept, mngr_no, budget, location, phone_no) values ('670', 'consumer electronics div.', '600', 107, 1150000, 'burlington, vt', '(802) 555-1234');
insert into department (dept_no, department, head_dept, mngr_no, budget, location, phone_no) values ('671', 'research and development', '670', 20, 460000, 'burlington, vt', '(802) 555-1234');
insert into department (dept_no, department, head_dept, mngr_no, budget, location, phone_no) values ('672', 'customer services', '670', 94, 850000, 'burlington, vt', '(802) 555-1234');
insert into department (dept_no, department, head_dept, mngr_no, budget, location, phone_no) values ('900', 'finance', '000', 46, 400000, 'monterey', '(408) 555-1234');


insert into employee (emp_no, first_name, last_name, phone_ext, hire_date, dept_no, job_code, job_grade, job_country, salary) values (2, 'robert', 'nelson', '250', '28-dec-1988 00:00:00', '600', 'vp', 2, 'usa', 105900);
insert into employee (emp_no, first_name, last_name, phone_ext, hire_date, dept_no, job_code, job_grade, job_country, salary) values (4, 'bruce', 'young', '233', '28-dec-1988 00:00:00', '621', 'eng', 2, 'usa', 97500);
insert into employee (emp_no, first_name, last_name, phone_ext, hire_date, dept_no, job_code, job_grade, job_country, salary) values (5, 'kim', 'lambert', '22', '6-feb-1989 00:00:00', '130', 'eng', 2, 'usa', 102750);
insert into employee (emp_no, first_name, last_name, phone_ext, hire_date, dept_no, job_code, job_grade, job_country, salary) values (8, 'leslie', 'johnson', '410', '5-apr-1989 00:00:00', '180', 'mktg', 3, 'usa', 64635);
insert into employee (emp_no, first_name, last_name, phone_ext, hire_date, dept_no, job_code, job_grade, job_country, salary) values (9, 'phil', 'forest', '229', '17-apr-1989 00:00:00', '622', 'mngr', 3, 'usa', 75060);
insert into employee (emp_no, first_name, last_name, phone_ext, hire_date, dept_no, job_code, job_grade, job_country, salary) values (11, 'k. j.', 'weston', '34', '17-jan-1990 00:00:00', '130', 'srep', 4, 'usa', 86292.94);
insert into employee (emp_no, first_name, last_name, phone_ext, hire_date, dept_no, job_code, job_grade, job_country, salary) values (12, 'terri', 'lee', '256', '1-may-1990 00:00:00', '000', 'admin', 4, 'usa', 53793);
insert into employee (emp_no, first_name, last_name, phone_ext, hire_date, dept_no, job_code, job_grade, job_country, salary) values (14, 'stewart', 'hall', '227', '4-jun-1990 00:00:00', '900', 'finan', 3, 'usa', 69482.63);
insert into employee (emp_no, first_name, last_name, phone_ext, hire_date, dept_no, job_code, job_grade, job_country, salary) values (15, 'katherine', 'young', '231', '14-jun-1990 00:00:00', '623', 'mngr', 3, 'usa', 67241.25);
insert into employee (emp_no, first_name, last_name, phone_ext, hire_date, dept_no, job_code, job_grade, job_country, salary) values (20, 'chris', 'papadopoulos', '887', '1-jan-1990 00:00:00', '671', 'mngr', 3, 'usa', 89655);
insert into employee (emp_no, first_name, last_name, phone_ext, hire_date, dept_no, job_code, job_grade, job_country, salary) values (24, 'pete', 'fisher', '888', '12-sep-1990 00:00:00', '671', 'eng', 3, 'usa', 81810.19);
insert into employee (emp_no, first_name, last_name, phone_ext, hire_date, dept_no, job_code, job_grade, job_country, salary) values (28, 'ann', 'bennet', '5', '1-feb-1991 00:00:00', '120', 'admin', 5, 'england', 22935);
insert into employee (emp_no, first_name, last_name, phone_ext, hire_date, dept_no, job_code, job_grade, job_country, salary) values (29, 'roger', 'de souza', '288', '18-feb-1991 00:00:00', '623', 'eng', 3, 'usa', 69482.63);
insert into employee (emp_no, first_name, last_name, phone_ext, hire_date, dept_no, job_code, job_grade, job_country, salary) values (34, 'janet', 'baldwin', '2', '21-mar-1991 00:00:00', '110', 'sales', 3, 'usa', 61637.81);
insert into employee (emp_no, first_name, last_name, phone_ext, hire_date, dept_no, job_code, job_grade, job_country, salary) values (36, 'roger', 'reeves', '6', '25-apr-1991 00:00:00', '120', 'sales', 3, 'england', 33620.63);
insert into employee (emp_no, first_name, last_name, phone_ext, hire_date, dept_no, job_code, job_grade, job_country, salary) values (37, 'willie', 'stansbury', '7', '25-apr-1991 00:00:00', '120', 'eng', 4, 'england', 39224.06);
insert into employee (emp_no, first_name, last_name, phone_ext, hire_date, dept_no, job_code, job_grade, job_country, salary) values (44, 'leslie', 'phong', '216', '3-jun-1991 00:00:00', '623', 'eng', 4, 'usa', 56034.38);
insert into employee (emp_no, first_name, last_name, phone_ext, hire_date, dept_no, job_code, job_grade, job_country, salary) values (45, 'ashok', 'ramanathan', '209', '1-aug-1991 00:00:00', '621', 'eng', 3, 'usa', 80689.5);
insert into employee (emp_no, first_name, last_name, phone_ext, hire_date, dept_no, job_code, job_grade, job_country, salary) values (46, 'walter', 'steadman', '210', '9-aug-1991 00:00:00', '900', 'cfo', 1, 'usa', 116100);
insert into employee (emp_no, first_name, last_name, phone_ext, hire_date, dept_no, job_code, job_grade, job_country, salary) values (52, 'carol', 'nordstrom', '420', '2-oct-1991 00:00:00', '180', 'prel', 4, 'usa', 42742.5);
insert into employee (emp_no, first_name, last_name, phone_ext, hire_date, dept_no, job_code, job_grade, job_country, salary) values (61, 'luke', 'leung', '3', '18-feb-1992 00:00:00', '110', 'srep', 4, 'usa', 68805);
insert into employee (emp_no, first_name, last_name, phone_ext, hire_date, dept_no, job_code, job_grade, job_country, salary) values (65, 'sue anne', 'o''brien', '877', '23-mar-1992 00:00:00', '670', 'admin', 5, 'usa', 31275);
insert into employee (emp_no, first_name, last_name, phone_ext, hire_date, dept_no, job_code, job_grade, job_country, salary) values (71, 'jennifer m.', 'burbank', '289', '15-apr-1992 00:00:00', '622', 'eng', 3, 'usa', 53167.5);
insert into employee (emp_no, first_name, last_name, phone_ext, hire_date, dept_no, job_code, job_grade, job_country, salary) values (72, 'claudia', 'sutherland', null, '20-apr-1992 00:00:00', '140', 'srep', 4, 'canada', 100914);
insert into employee (emp_no, first_name, last_name, phone_ext, hire_date, dept_no, job_code, job_grade, job_country, salary) values (83, 'dana', 'bishop', '290', '1-jun-1992 00:00:00', '621', 'eng', 3, 'usa', 62550);
insert into employee (emp_no, first_name, last_name, phone_ext, hire_date, dept_no, job_code, job_grade, job_country, salary) values (85, 'mary s.', 'macdonald', '477', '1-jun-1992 00:00:00', '100', 'vp', 2, 'usa', 111262.5);
insert into employee (emp_no, first_name, last_name, phone_ext, hire_date, dept_no, job_code, job_grade, job_country, salary) values (94, 'randy', 'williams', '892', '8-aug-1992 00:00:00', '672', 'mngr', 4, 'usa', 56295);
insert into employee (emp_no, first_name, last_name, phone_ext, hire_date, dept_no, job_code, job_grade, job_country, salary) values (105, 'oliver h.', 'bender', '255', '8-oct-1992 00:00:00', '000', 'ceo', 1, 'usa', 212850);
insert into employee (emp_no, first_name, last_name, phone_ext, hire_date, dept_no, job_code, job_grade, job_country, salary) values (107, 'kevin', 'cook', '894', '1-feb-1993 00:00:00', '670', 'dir', 2, 'usa', 111262.5);
insert into employee (emp_no, first_name, last_name, phone_ext, hire_date, dept_no, job_code, job_grade, job_country, salary) values (109, 'kelly', 'brown', '202', '4-feb-1993 00:00:00', '600', 'admin', 5, 'usa', 27000);
insert into employee (emp_no, first_name, last_name, phone_ext, hire_date, dept_no, job_code, job_grade, job_country, salary) values (110, 'yuki', 'ichida', '22', '4-feb-1993 00:00:00', '115', 'eng', 3, 'japan', 6000000);
insert into employee (emp_no, first_name, last_name, phone_ext, hire_date, dept_no, job_code, job_grade, job_country, salary) values (113, 'mary', 'page', '845', '12-apr-1993 00:00:00', '671', 'eng', 4, 'usa', 48000);
insert into employee (emp_no, first_name, last_name, phone_ext, hire_date, dept_no, job_code, job_grade, job_country, salary) values (114, 'bill', 'parker', '247', '1-jun-1993 00:00:00', '623', 'eng', 5, 'usa', 35000);
insert into employee (emp_no, first_name, last_name, phone_ext, hire_date, dept_no, job_code, job_grade, job_country, salary) values (118, 'takashi', 'yamamoto', '23', '1-jul-1993 00:00:00', '115', 'srep', 4, 'japan', 7480000);
insert into employee (emp_no, first_name, last_name, phone_ext, hire_date, dept_no, job_code, job_grade, job_country, salary) values (121, 'roberto', 'ferrari', '1', '12-jul-1993 00:00:00', '125', 'srep', 4, 'italy', 33000);
insert into employee (emp_no, first_name, last_name, phone_ext, hire_date, dept_no, job_code, job_grade, job_country, salary) values (127, 'michael', 'yanowski', '492', '9-aug-1993 00:00:00', '100', 'srep', 4, 'usa', 44000);
insert into employee (emp_no, first_name, last_name, phone_ext, hire_date, dept_no, job_code, job_grade, job_country, salary) values (134, 'jacques', 'glon', null, '23-aug-1993 00:00:00', '123', 'srep', 4, 'france', 38500);
insert into employee (emp_no, first_name, last_name, phone_ext, hire_date, dept_no, job_code, job_grade, job_country, salary) values (136, 'scott', 'johnson', '265', '13-sep-1993 00:00:00', '623', 'doc', 3, 'usa', 60000);
insert into employee (emp_no, first_name, last_name, phone_ext, hire_date, dept_no, job_code, job_grade, job_country, salary) values (138, 't.j.', 'green', '218', '1-nov-1993 00:00:00', '621', 'eng', 4, 'usa', 36000);
insert into employee (emp_no, first_name, last_name, phone_ext, hire_date, dept_no, job_code, job_grade, job_country, salary) values (141, 'pierre', 'osborne', null, '3-jan-1994 00:00:00', '121', 'srep', 4, 'switzerland', 110000);
insert into employee (emp_no, first_name, last_name, phone_ext, hire_date, dept_no, job_code, job_grade, job_country, salary) values (144, 'john', 'montgomery', '820', '30-mar-1994 00:00:00', '672', 'eng', 5, 'usa', 35000);
insert into employee (emp_no, first_name, last_name, phone_ext, hire_date, dept_no, job_code, job_grade, job_country, salary) values (145, 'mark', 'guckenheimer', '221', '2-may-1994 00:00:00', '622', 'eng', 5, 'usa', 32000);


insert into employee_project (emp_no, proj_id) values (4, 'mapdb');
insert into employee_project (emp_no, proj_id) values (4, 'vbase');
insert into employee_project (emp_no, proj_id) values (8, 'guide');
insert into employee_project (emp_no, proj_id) values (8, 'mktpr');
insert into employee_project (emp_no, proj_id) values (8, 'vbase');
insert into employee_project (emp_no, proj_id) values (12, 'mktpr');
insert into employee_project (emp_no, proj_id) values (14, 'mktpr');
insert into employee_project (emp_no, proj_id) values (15, 'vbase');
insert into employee_project (emp_no, proj_id) values (20, 'guide');
insert into employee_project (emp_no, proj_id) values (24, 'dgpii');
insert into employee_project (emp_no, proj_id) values (24, 'guide');
insert into employee_project (emp_no, proj_id) values (34, 'mktpr');
insert into employee_project (emp_no, proj_id) values (44, 'vbase');
insert into employee_project (emp_no, proj_id) values (45, 'vbase');
insert into employee_project (emp_no, proj_id) values (46, 'mktpr');
insert into employee_project (emp_no, proj_id) values (52, 'mktpr');
insert into employee_project (emp_no, proj_id) values (71, 'mapdb');
insert into employee_project (emp_no, proj_id) values (71, 'vbase');
insert into employee_project (emp_no, proj_id) values (83, 'vbase');
insert into employee_project (emp_no, proj_id) values (85, 'mktpr');
insert into employee_project (emp_no, proj_id) values (105, 'mktpr');
insert into employee_project (emp_no, proj_id) values (110, 'mktpr');
insert into employee_project (emp_no, proj_id) values (113, 'dgpii');
insert into employee_project (emp_no, proj_id) values (113, 'guide');
insert into employee_project (emp_no, proj_id) values (136, 'vbase');
insert into employee_project (emp_no, proj_id) values (138, 'vbase');
insert into employee_project (emp_no, proj_id) values (144, 'dgpii');
insert into employee_project (emp_no, proj_id) values (145, 'vbase');



insert into job (job_code, job_grade, job_country, job_title, min_salary, max_salary, job_requirement, language_req) values ('accnt', 4, 'usa', 'accountant', 28000, 55000, null, null);
insert into job (job_code, job_grade, job_country, job_title, min_salary, max_salary, job_requirement, language_req) values ('admin', 4, 'usa', 'administrative assistant', 35000, 55000, null, null);
insert into job (job_code, job_grade, job_country, job_title, min_salary, max_salary, job_requirement, language_req) values ('admin', 5, 'england', 'administrative assistant', 13400, 26800, null, null);
insert into job (job_code, job_grade, job_country, job_title, min_salary, max_salary, job_requirement, language_req) values ('admin', 5, 'usa', 'administrative assistant', 20000, 40000, null, null);
insert into job (job_code, job_grade, job_country, job_title, min_salary, max_salary, job_requirement, language_req) values ('ceo', 1, 'usa', 'chief executive officer', 130000, 250000, null, null);
insert into job (job_code, job_grade, job_country, job_title, min_salary, max_salary, job_requirement, language_req) values ('cfo', 1, 'usa', 'chief financial officer', 85000, 140000, null, null);
insert into job (job_code, job_grade, job_country, job_title, min_salary, max_salary, job_requirement, language_req) values ('dir', 2, 'usa', 'director', 75000, 120000, null, null);
insert into job (job_code, job_grade, job_country, job_title, min_salary, max_salary, job_requirement, language_req) values ('doc', 3, 'usa', 'technical writer', 38000, 60000, null, null);
insert into job (job_code, job_grade, job_country, job_title, min_salary, max_salary, job_requirement, language_req) values ('doc', 5, 'usa', 'technical writer', 22000, 40000, null, null);
insert into job (job_code, job_grade, job_country, job_title, min_salary, max_salary, job_requirement, language_req) values ('eng', 2, 'usa', 'engineer', 70000, 110000, null, null);
insert into job (job_code, job_grade, job_country, job_title, min_salary, max_salary, job_requirement, language_req) values ('eng', 3, 'japan', 'engineer', 5400000, 9720000, null, null);
insert into job (job_code, job_grade, job_country, job_title, min_salary, max_salary, job_requirement, language_req) values ('eng', 3, 'usa', 'engineer', 50000, 90000, null, null);
insert into job (job_code, job_grade, job_country, job_title, min_salary, max_salary, job_requirement, language_req) values ('eng', 4, 'england', 'engineer', 20100, 43550, null, null);
insert into job (job_code, job_grade, job_country, job_title, min_salary, max_salary, job_requirement, language_req) values ('eng', 4, 'usa', 'engineer', 30000, 65000, null, null);
insert into job (job_code, job_grade, job_country, job_title, min_salary, max_salary, job_requirement, language_req) values ('eng', 5, 'usa', 'engineer', 25000, 35000, null, null);
insert into job (job_code, job_grade, job_country, job_title, min_salary, max_salary, job_requirement, language_req) values ('finan', 3, 'usa', 'financial analyst', 35000, 85000, null, null);
insert into job (job_code, job_grade, job_country, job_title, min_salary, max_salary, job_requirement, language_req) values ('mktg', 3, 'usa', 'marketing analyst', 40000, 80000, null, null);
insert into job (job_code, job_grade, job_country, job_title, min_salary, max_salary, job_requirement, language_req) values ('mktg', 4, 'usa', 'marketing analyst', 20000, 50000, null, null);
insert into job (job_code, job_grade, job_country, job_title, min_salary, max_salary, job_requirement, language_req) values ('mngr', 3, 'usa', 'manager', 60000, 100000, null, null);
insert into job (job_code, job_grade, job_country, job_title, min_salary, max_salary, job_requirement, language_req) values ('mngr', 4, 'usa', 'manager', 30000, 60000, null, null);
insert into job (job_code, job_grade, job_country, job_title, min_salary, max_salary, job_requirement, language_req) values ('prel', 4, 'usa', 'public relations rep.', 25000, 65000, null, null);
insert into job (job_code, job_grade, job_country, job_title, min_salary, max_salary, job_requirement, language_req) values ('srep', 4, 'canada', 'sales representative', 26400, 132000, null, null);
insert into job (job_code, job_grade, job_country, job_title, min_salary, max_salary, job_requirement, language_req) values ('srep', 4, 'england', 'sales representative', 13400, 67000, null, null);
insert into job (job_code, job_grade, job_country, job_title, min_salary, max_salary, job_requirement, language_req) values ('srep', 4, 'france', 'sales representative', 20000, 100000, null, null);
insert into job (job_code, job_grade, job_country, job_title, min_salary, max_salary, job_requirement, language_req) values ('srep', 4, 'italy', 'sales representative', 20000, 100000, null, null);
insert into job (job_code, job_grade, job_country, job_title, min_salary, max_salary, job_requirement, language_req) values ('srep', 4, 'japan', 'sales representative', 2160000, 10800000, null, null);
insert into job (job_code, job_grade, job_country, job_title, min_salary, max_salary, job_requirement, language_req) values ('srep', 4, 'switzerland', 'sales representative', 28000, 149000, null, null);
insert into job (job_code, job_grade, job_country, job_title, min_salary, max_salary, job_requirement, language_req) values ('srep', 4, 'usa', 'sales representative', 20000, 100000, null, null);
insert into job (job_code, job_grade, job_country, job_title, min_salary, max_salary, job_requirement, language_req) values ('sales', 3, 'england', 'sales co-ordinator', 26800, 46900, null, null);
insert into job (job_code, job_grade, job_country, job_title, min_salary, max_salary, job_requirement, language_req) values ('sales', 3, 'usa', 'sales co-ordinator', 40000, 70000, null, null);
insert into job (job_code, job_grade, job_country, job_title, min_salary, max_salary, job_requirement, language_req) values ('vp', 2, 'usa', 'vice president', 80000, 130000, null, null);


insert into project (proj_id, proj_name, proj_desc, team_leader, product) values ('dgpii', 'digipizza', null, 24, 'other');
insert into project (proj_id, proj_name, proj_desc, team_leader, product) values ('guide', 'automap', null, 20, 'hardware');
insert into project (proj_id, proj_name, proj_desc, team_leader, product) values ('hwrii', 'translator upgrade', null, null, 'software');
insert into project (proj_id, proj_name, proj_desc, team_leader, product) values ('mapdb', 'mapbrowser port', null, 4, 'software');
insert into project (proj_id, proj_name, proj_desc, team_leader, product) values ('mktpr', 'marketing project 3', null, 85, 'n/a');
insert into project (proj_id, proj_name, proj_desc, team_leader, product) values ('vbase', 'video database', null, 45, 'software');



insert into proj_dept_budget (fiscal_year, proj_id, dept_no, quart_head_cnt, projected_budget) values (1993, 'mapdb', '621', null, 20000);
insert into proj_dept_budget (fiscal_year, proj_id, dept_no, quart_head_cnt, projected_budget) values (1994, 'guide', '100', null, 200000);
insert into proj_dept_budget (fiscal_year, proj_id, dept_no, quart_head_cnt, projected_budget) values (1994, 'guide', '671', null, 450000);
insert into proj_dept_budget (fiscal_year, proj_id, dept_no, quart_head_cnt, projected_budget) values (1994, 'hwrii', '621', null, 400000);
insert into proj_dept_budget (fiscal_year, proj_id, dept_no, quart_head_cnt, projected_budget) values (1994, 'hwrii', '622', null, 100000);
insert into proj_dept_budget (fiscal_year, proj_id, dept_no, quart_head_cnt, projected_budget) values (1994, 'hwrii', '670', null, 20000);
insert into proj_dept_budget (fiscal_year, proj_id, dept_no, quart_head_cnt, projected_budget) values (1994, 'mapdb', '621', null, 40000);
insert into proj_dept_budget (fiscal_year, proj_id, dept_no, quart_head_cnt, projected_budget) values (1994, 'mapdb', '622', null, 60000);
insert into proj_dept_budget (fiscal_year, proj_id, dept_no, quart_head_cnt, projected_budget) values (1994, 'mapdb', '671', null, 11000);
insert into proj_dept_budget (fiscal_year, proj_id, dept_no, quart_head_cnt, projected_budget) values (1994, 'mktpr', '000', null, 100000);
insert into proj_dept_budget (fiscal_year, proj_id, dept_no, quart_head_cnt, projected_budget) values (1994, 'mktpr', '100', null, 1000000);
insert into proj_dept_budget (fiscal_year, proj_id, dept_no, quart_head_cnt, projected_budget) values (1994, 'mktpr', '110', null, 200000);
insert into proj_dept_budget (fiscal_year, proj_id, dept_no, quart_head_cnt, projected_budget) values (1994, 'mktpr', '623', null, 80000);
insert into proj_dept_budget (fiscal_year, proj_id, dept_no, quart_head_cnt, projected_budget) values (1994, 'mktpr', '672', null, 100000);
insert into proj_dept_budget (fiscal_year, proj_id, dept_no, quart_head_cnt, projected_budget) values (1994, 'vbase', '100', null, 300000);
insert into proj_dept_budget (fiscal_year, proj_id, dept_no, quart_head_cnt, projected_budget) values (1994, 'vbase', '621', null, 1900000);
insert into proj_dept_budget (fiscal_year, proj_id, dept_no, quart_head_cnt, projected_budget) values (1994, 'vbase', '622', null, 400000);
insert into proj_dept_budget (fiscal_year, proj_id, dept_no, quart_head_cnt, projected_budget) values (1995, 'mktpr', '100', null, 2000000);
insert into proj_dept_budget (fiscal_year, proj_id, dept_no, quart_head_cnt, projected_budget) values (1995, 'mktpr', '110', null, 1200000);
insert into proj_dept_budget (fiscal_year, proj_id, dept_no, quart_head_cnt, projected_budget) values (1995, 'mktpr', '623', null, 1200000);
insert into proj_dept_budget (fiscal_year, proj_id, dept_no, quart_head_cnt, projected_budget) values (1995, 'mktpr', '672', null, 800000);
insert into proj_dept_budget (fiscal_year, proj_id, dept_no, quart_head_cnt, projected_budget) values (1995, 'vbase', '100', null, 1500000);
insert into proj_dept_budget (fiscal_year, proj_id, dept_no, quart_head_cnt, projected_budget) values (1995, 'vbase', '621', null, 900000);
insert into proj_dept_budget (fiscal_year, proj_id, dept_no, quart_head_cnt, projected_budget) values (1996, 'vbase', '100', null, 150000);



insert into salary_history (emp_no, change_date, updater_id, old_salary, percent_change) values (2, '15-dec-1992 00:00:00', 'admin2', 98000, 8.0612);
insert into salary_history (emp_no, change_date, updater_id, old_salary, percent_change) values (4, '15-dec-1992 00:00:00', 'admin2', 90000, 8.3333);
insert into salary_history (emp_no, change_date, updater_id, old_salary, percent_change) values (5, '15-dec-1992 00:00:00', 'admin2', 95000, 8.1578);
insert into salary_history (emp_no, change_date, updater_id, old_salary, percent_change) values (8, '8-sep-1993 00:00:00', 'elaine', 62000, 4.25);
insert into salary_history (emp_no, change_date, updater_id, old_salary, percent_change) values (9, '8-sep-1993 00:00:00', 'elaine', 72000, 4.25);
insert into salary_history (emp_no, change_date, updater_id, old_salary, percent_change) values (11, '15-dec-1992 00:00:00', 'admin2', 70000, 7.5);
insert into salary_history (emp_no, change_date, updater_id, old_salary, percent_change) values (11, '8-sep-1993 00:00:00', 'elaine', 75250, 4.25);
insert into salary_history (emp_no, change_date, updater_id, old_salary, percent_change) values (11, '20-dec-1993 00:00:00', 'elaine', 78448.13, 9.9999);
insert into salary_history (emp_no, change_date, updater_id, old_salary, percent_change) values (12, '15-dec-1992 00:00:00', 'admin2', 48000, 7.5);
insert into salary_history (emp_no, change_date, updater_id, old_salary, percent_change) values (12, '8-sep-1993 00:00:00', 'elaine', 51600, 4.25);
insert into salary_history (emp_no, change_date, updater_id, old_salary, percent_change) values (14, '15-dec-1992 00:00:00', 'admin2', 62000, 7.5);
insert into salary_history (emp_no, change_date, updater_id, old_salary, percent_change) values (14, '8-sep-1993 00:00:00', 'elaine', 66650, 4.25);
insert into salary_history (emp_no, change_date, updater_id, old_salary, percent_change) values (15, '15-dec-1992 00:00:00', 'admin2', 60000, 7.5);
insert into salary_history (emp_no, change_date, updater_id, old_salary, percent_change) values (15, '8-sep-1993 00:00:00', 'elaine', 64500, 4.25);
insert into salary_history (emp_no, change_date, updater_id, old_salary, percent_change) values (20, '15-dec-1992 00:00:00', 'admin2', 80000, 7.5);
insert into salary_history (emp_no, change_date, updater_id, old_salary, percent_change) values (20, '8-sep-1993 00:00:00', 'elaine', 86000, 4.25);
insert into salary_history (emp_no, change_date, updater_id, old_salary, percent_change) values (24, '15-dec-1992 00:00:00', 'admin2', 73000, 7.5);
insert into salary_history (emp_no, change_date, updater_id, old_salary, percent_change) values (24, '8-sep-1993 00:00:00', 'elaine', 78475, 4.25);
insert into salary_history (emp_no, change_date, updater_id, old_salary, percent_change) values (28, '15-dec-1992 00:00:00', 'admin2', 20000, 10);
insert into salary_history (emp_no, change_date, updater_id, old_salary, percent_change) values (28, '8-sep-1993 00:00:00', 'elaine', 22000, 4.25);
insert into salary_history (emp_no, change_date, updater_id, old_salary, percent_change) values (29, '15-dec-1992 00:00:00', 'admin2', 62000, 7.5);
insert into salary_history (emp_no, change_date, updater_id, old_salary, percent_change) values (29, '8-sep-1993 00:00:00', 'elaine', 66650, 4.25);
insert into salary_history (emp_no, change_date, updater_id, old_salary, percent_change) values (34, '15-dec-1992 00:00:00', 'admin2', 55000, 7.5);
insert into salary_history (emp_no, change_date, updater_id, old_salary, percent_change) values (34, '8-sep-1993 00:00:00', 'elaine', 59125, 4.2499);
insert into salary_history (emp_no, change_date, updater_id, old_salary, percent_change) values (36, '15-dec-1992 00:00:00', 'admin2', 30000, 7.5);
insert into salary_history (emp_no, change_date, updater_id, old_salary, percent_change) values (36, '8-sep-1993 00:00:00', 'elaine', 32250, 4.25);
insert into salary_history (emp_no, change_date, updater_id, old_salary, percent_change) values (37, '15-dec-1992 00:00:00', 'admin2', 35000, 7.5);
insert into salary_history (emp_no, change_date, updater_id, old_salary, percent_change) values (37, '8-sep-1993 00:00:00', 'elaine', 37625, 4.2499);
insert into salary_history (emp_no, change_date, updater_id, old_salary, percent_change) values (44, '15-dec-1992 00:00:00', 'admin2', 50000, 7.5);
insert into salary_history (emp_no, change_date, updater_id, old_salary, percent_change) values (44, '8-sep-1993 00:00:00', 'elaine', 53750, 4.25);
insert into salary_history (emp_no, change_date, updater_id, old_salary, percent_change) values (45, '15-dec-1992 00:00:00', 'admin2', 72000, 7.5);
insert into salary_history (emp_no, change_date, updater_id, old_salary, percent_change) values (45, '8-sep-1993 00:00:00', 'elaine', 77400, 4.25);
insert into salary_history (emp_no, change_date, updater_id, old_salary, percent_change) values (46, '20-dec-1993 00:00:00', 'tj', 120000, -3.25);
insert into salary_history (emp_no, change_date, updater_id, old_salary, percent_change) values (52, '8-sep-1993 00:00:00', 'elaine', 41000, 4.25);
insert into salary_history (emp_no, change_date, updater_id, old_salary, percent_change) values (61, '8-sep-1993 00:00:00', 'elaine', 60000, 4.25);
insert into salary_history (emp_no, change_date, updater_id, old_salary, percent_change) values (61, '20-dec-1993 00:00:00', 'elaine', 62550, 10);
insert into salary_history (emp_no, change_date, updater_id, old_salary, percent_change) values (65, '8-sep-1993 00:00:00', 'elaine', 30000, 4.25);
insert into salary_history (emp_no, change_date, updater_id, old_salary, percent_change) values (71, '8-sep-1993 00:00:00', 'elaine', 51000, 4.25);
insert into salary_history (emp_no, change_date, updater_id, old_salary, percent_change) values (72, '8-sep-1993 00:00:00', 'elaine', 88000, 4.25);
insert into salary_history (emp_no, change_date, updater_id, old_salary, percent_change) values (72, '20-dec-1993 00:00:00', 'elaine', 91740, 10);
insert into salary_history (emp_no, change_date, updater_id, old_salary, percent_change) values (83, '8-sep-1993 00:00:00', 'elaine', 60000, 4.25);
insert into salary_history (emp_no, change_date, updater_id, old_salary, percent_change) values (85, '20-dec-1993 00:00:00', 'tj', 115000, -3.25);
insert into salary_history (emp_no, change_date, updater_id, old_salary, percent_change) values (94, '8-sep-1993 00:00:00', 'elaine', 54000, 4.25);
insert into salary_history (emp_no, change_date, updater_id, old_salary, percent_change) values (105, '20-dec-1993 00:00:00', 'tj', 220000, -3.25);
insert into salary_history (emp_no, change_date, updater_id, old_salary, percent_change) values (107, '20-dec-1993 00:00:00', 'tj', 115000, -3.25);
insert into salary_history (emp_no, change_date, updater_id, old_salary, percent_change) values (118, '20-dec-1993 00:00:00', 'elaine', 6800000, 10);
insert into salary_history (emp_no, change_date, updater_id, old_salary, percent_change) values (121, '20-dec-1993 00:00:00', 'elaine', 30000, 10);
insert into salary_history (emp_no, change_date, updater_id, old_salary, percent_change) values (127, '20-dec-1993 00:00:00', 'elaine', 40000, 10);
insert into salary_history (emp_no, change_date, updater_id, old_salary, percent_change) values (134, '20-dec-1993 00:00:00', 'elaine', 35000, 10);



insert into sales (po_number, cust_no, sales_rep, order_status, order_date, ship_date, date_needed, paid, qty_ordered, total_value, discount, item_type) values ('v91e0210', 1004, 11, 'shipped', '4-mar-1991 00:00:00', '5-mar-1991 00:00:00', null, 'y', 10, 5000, 0.100000001490116, 'hardware');
insert into sales (po_number, cust_no, sales_rep, order_status, order_date, ship_date, date_needed, paid, qty_ordered, total_value, discount, item_type) values ('v92e0340', 1004, 11, 'shipped', '15-oct-1992 00:00:00', '16-oct-1992 00:00:00', '17-oct-1992 00:00:00', 'y', 7, 70000, 0, 'hardware');
insert into sales (po_number, cust_no, sales_rep, order_status, order_date, ship_date, date_needed, paid, qty_ordered, total_value, discount, item_type) values ('v92f3004', 1012, 11, 'shipped', '15-oct-1992 00:00:00', '16-jan-1993 00:00:00', '16-jan-1993 00:00:00', 'y', 3, 2000, 0, 'software');
insert into sales (po_number, cust_no, sales_rep, order_status, order_date, ship_date, date_needed, paid, qty_ordered, total_value, discount, item_type) values ('v92j1003', 1010, 61, 'shipped', '26-jul-1992 00:00:00', '4-aug-1992 00:00:00', '15-sep-1992 00:00:00', 'y', 15, 2985, 0, 'software');
insert into sales (po_number, cust_no, sales_rep, order_status, order_date, ship_date, date_needed, paid, qty_ordered, total_value, discount, item_type) values ('v9320630', 1001, 127, 'open', '12-dec-1993 00:00:00', null, '15-dec-1993 00:00:00', 'n', 3, 60000, 0.200000002980232, 'hardware');
insert into sales (po_number, cust_no, sales_rep, order_status, order_date, ship_date, date_needed, paid, qty_ordered, total_value, discount, item_type) values ('v9324200', 1001, 72, 'shipped', '9-aug-1993 00:00:00', '9-aug-1993 00:00:00', '17-aug-1993 00:00:00', 'y', 1000, 560000, 0.200000002980232, 'hardware');
insert into sales (po_number, cust_no, sales_rep, order_status, order_date, ship_date, date_needed, paid, qty_ordered, total_value, discount, item_type) values ('v9324320', 1001, 127, 'shipped', '16-aug-1993 00:00:00', '16-aug-1993 00:00:00', '1-sep-1993 00:00:00', 'y', 1, 0, 1, 'software');
insert into sales (po_number, cust_no, sales_rep, order_status, order_date, ship_date, date_needed, paid, qty_ordered, total_value, discount, item_type) values ('v9333005', 1002, 11, 'shipped', '3-feb-1993 00:00:00', '3-mar-1993 00:00:00', null, 'y', 2, 600.5, 0, 'software');
insert into sales (po_number, cust_no, sales_rep, order_status, order_date, ship_date, date_needed, paid, qty_ordered, total_value, discount, item_type) values ('v9333006', 1002, 11, 'shipped', '27-apr-1993 00:00:00', '2-may-1993 00:00:00', '2-may-1993 00:00:00', 'n', 5, 20000, 0, 'other');
insert into sales (po_number, cust_no, sales_rep, order_status, order_date, ship_date, date_needed, paid, qty_ordered, total_value, discount, item_type) values ('v9336100', 1002, 11, 'waiting', '27-dec-1993 00:00:00', '1-jan-1994 00:00:00', '1-jan-1994 00:00:00', 'n', 150, 14850, 0.0500000007450581, 'software');
insert into sales (po_number, cust_no, sales_rep, order_status, order_date, ship_date, date_needed, paid, qty_ordered, total_value, discount, item_type) values ('v9345139', 1003, 127, 'shipped', '9-sep-1993 00:00:00', '20-sep-1993 00:00:00', '1-oct-1993 00:00:00', 'y', 20, 12582.12, 0.100000001490116, 'software');
insert into sales (po_number, cust_no, sales_rep, order_status, order_date, ship_date, date_needed, paid, qty_ordered, total_value, discount, item_type) values ('v9345200', 1003, 11, 'shipped', '11-nov-1993 00:00:00', '2-dec-1993 00:00:00', '1-dec-1993 00:00:00', 'y', 900, 27000, 0.300000011920929, 'software');
insert into sales (po_number, cust_no, sales_rep, order_status, order_date, ship_date, date_needed, paid, qty_ordered, total_value, discount, item_type) values ('v9346200', 1003, 11, 'waiting', '31-dec-1993 00:00:00', null, '24-jan-1994 00:00:00', 'n', 3, 0, 1, 'software');
insert into sales (po_number, cust_no, sales_rep, order_status, order_date, ship_date, date_needed, paid, qty_ordered, total_value, discount, item_type) values ('v93b1002', 1014, 134, 'shipped', '20-sep-1993 00:00:00', '21-sep-1993 00:00:00', '25-sep-1993 00:00:00', 'y', 1, 100.02, 0, 'software');
insert into sales (po_number, cust_no, sales_rep, order_status, order_date, ship_date, date_needed, paid, qty_ordered, total_value, discount, item_type) values ('v93c0120', 1006, 72, 'shipped', '22-mar-1993 00:00:00', '31-may-1993 00:00:00', '17-apr-1993 00:00:00', 'y', 1, 47.5, 0, 'other');
insert into sales (po_number, cust_no, sales_rep, order_status, order_date, ship_date, date_needed, paid, qty_ordered, total_value, discount, item_type) values ('v93c0990', 1006, 72, 'shipped', '9-aug-1993 00:00:00', '2-sep-1993 00:00:00', null, 'y', 40, 399960.5, 0.100000001490116, 'hardware');
insert into sales (po_number, cust_no, sales_rep, order_status, order_date, ship_date, date_needed, paid, qty_ordered, total_value, discount, item_type) values ('v93f0020', 1009, 61, 'shipped', '10-oct-1993 00:00:00', '11-nov-1993 00:00:00', '11-nov-1993 00:00:00', 'n', 1, 490.69, 0, 'software');
insert into sales (po_number, cust_no, sales_rep, order_status, order_date, ship_date, date_needed, paid, qty_ordered, total_value, discount, item_type) values ('v93f2030', 1012, 134, 'open', '12-dec-1993 00:00:00', null, null, 'y', 15, 450000.49, 0, 'hardware');
insert into sales (po_number, cust_no, sales_rep, order_status, order_date, ship_date, date_needed, paid, qty_ordered, total_value, discount, item_type) values ('v93f2051', 1012, 134, 'waiting', '18-dec-1993 00:00:00', null, '1-mar-1994 00:00:00', 'n', 1, 999.98, 0, 'software');
insert into sales (po_number, cust_no, sales_rep, order_status, order_date, ship_date, date_needed, paid, qty_ordered, total_value, discount, item_type) values ('v93f3088', 1012, 134, 'shipped', '27-aug-1993 00:00:00', '8-sep-1993 00:00:00', null, 'n', 10, 10000, 0, 'software');
insert into sales (po_number, cust_no, sales_rep, order_status, order_date, ship_date, date_needed, paid, qty_ordered, total_value, discount, item_type) values ('v93h0030', 1005, 118, 'open', '12-dec-1993 00:00:00', null, '1-jan-1994 00:00:00', 'y', 20, 5980, 0.200000002980232, 'software');
insert into sales (po_number, cust_no, sales_rep, order_status, order_date, ship_date, date_needed, paid, qty_ordered, total_value, discount, item_type) values ('v93h0500', 1008, 61, 'open', '12-dec-1993 00:00:00', null, '15-dec-1993 00:00:00', 'n', 3, 16000, 0.200000002980232, 'hardware');
insert into sales (po_number, cust_no, sales_rep, order_status, order_date, ship_date, date_needed, paid, qty_ordered, total_value, discount, item_type) values ('v93h3009', 1008, 61, 'shipped', '1-aug-1993 00:00:00', '2-dec-1993 00:00:00', '1-dec-1993 00:00:00', 'n', 3, 9000, 0.0500000007450581, 'software');
insert into sales (po_number, cust_no, sales_rep, order_status, order_date, ship_date, date_needed, paid, qty_ordered, total_value, discount, item_type) values ('v93i4700', 1013, 121, 'open', '27-oct-1993 00:00:00', null, '15-dec-1993 00:00:00', 'n', 5, 2693, 0, 'hardware');
insert into sales (po_number, cust_no, sales_rep, order_status, order_date, ship_date, date_needed, paid, qty_ordered, total_value, discount, item_type) values ('v93j2004', 1010, 118, 'shipped', '30-oct-1993 00:00:00', '2-dec-1993 00:00:00', '15-nov-1993 00:00:00', 'y', 3, 210, 0, 'software');
insert into sales (po_number, cust_no, sales_rep, order_status, order_date, ship_date, date_needed, paid, qty_ordered, total_value, discount, item_type) values ('v93j3100', 1010, 118, 'shipped', '20-aug-1993 00:00:00', '20-aug-1993 00:00:00', null, 'y', 16, 18000.4, 0.100000001490116, 'software');
insert into sales (po_number, cust_no, sales_rep, order_status, order_date, ship_date, date_needed, paid, qty_ordered, total_value, discount, item_type) values ('v93n5822', 1015, 134, 'shipped', '18-dec-1993 00:00:00', '14-jan-1994 00:00:00', null, 'n', 2, 1500, 0, 'software');
insert into sales (po_number, cust_no, sales_rep, order_status, order_date, ship_date, date_needed, paid, qty_ordered, total_value, discount, item_type) values ('v93s4702', 1011, 121, 'shipped', '27-oct-1993 00:00:00', '28-oct-1993 00:00:00', '15-dec-1993 00:00:00', 'y', 4, 120000, 0, 'hardware');
insert into sales (po_number, cust_no, sales_rep, order_status, order_date, ship_date, date_needed, paid, qty_ordered, total_value, discount, item_type) values ('v9420099', 1001, 127, 'open', '17-jan-1994 00:00:00', null, '1-jun-1994 00:00:00', 'n', 100, 3399.15, 0.150000005960464, 'software');
insert into sales (po_number, cust_no, sales_rep, order_status, order_date, ship_date, date_needed, paid, qty_ordered, total_value, discount, item_type) values ('v9427029', 1001, 127, 'shipped', '7-feb-1994 00:00:00', '10-feb-1994 00:00:00', '10-feb-1994 00:00:00', 'n', 17, 422210.97, 0, 'hardware');
insert into sales (po_number, cust_no, sales_rep, order_status, order_date, ship_date, date_needed, paid, qty_ordered, total_value, discount, item_type) values ('v9456220', 1007, 127, 'open', '4-jan-1994 00:00:00', null, '30-jan-1994 00:00:00', 'y', 1, 3999.99, 0, 'hardware');
insert into sales (po_number, cust_no, sales_rep, order_status, order_date, ship_date, date_needed, paid, qty_ordered, total_value, discount, item_type) values ('v94h0079', 1005, 61, 'open', '13-feb-1994 00:00:00', null, '20-apr-1994 00:00:00', 'n', 10, 9000, 0.0500000007450581, 'software');
insert into sales (po_number, cust_no, sales_rep, order_status, order_date, ship_date, date_needed, paid, qty_ordered, total_value, discount, item_type) values ('v94s6400', 1011, 141, 'waiting', '6-jan-1994 00:00:00', null, '15-feb-1994 00:00:00', 'y', 20, 1980.72, 0.400000005960464, 'software');


commit;

-- #########################
-- ###   I N D I C E S   ###
-- #########################


create index custnamex on customer (customer);
create index custregion on customer (country, city);
create descending index budgetx on department (budget);
create index namex on employee (last_name, first_name);
create descending index maxsalx on job (job_country, max_salary);
create index minsalx on job (job_country, min_salary);
create unique index prodtypex on project (product, proj_name);
create descending index changex on salary_history (change_date);
create index updaterx on salary_history (updater_id);
create index needx on sales (date_needed);
create descending index qtyx on sales (item_type, qty_ordered);
create index salestatx on sales (order_status, paid);


-- ###################################
-- ###   F O R E I G N    K E Y S  ###
-- ###################################

alter table customer add foreign key (country) references country (country) using index customer_country_fk_country;
alter table department add foreign key (head_dept) references department (dept_no) using index dept_dept_fk_head_dept;
alter table department add foreign key (mngr_no) references employee (emp_no) using index department_employee_fk_mngr_no;
alter table employee add foreign key (dept_no) references department (dept_no) using index employee_department_fk_dept_no;
alter table employee add foreign key (job_code, job_grade, job_country) references job (job_code, job_grade, job_country) using index employee_job_fk_compound;
alter table employee_project add foreign key (emp_no) references employee (emp_no) using index empproj_employee_fk_emp_no;
alter table employee_project add foreign key (proj_id) references project (proj_id) using index empproj_project_fk_proj_id;
alter table job add foreign key (job_country) references country (country) using index job_country_fk_country;
alter table project add foreign key (team_leader) references employee (emp_no) using index project_employee_fk_team_leader;
alter table proj_dept_budget add foreign key (dept_no) references department (dept_no) using index pdep_budget_dept_fk_depno;
alter table proj_dept_budget add foreign key (proj_id) references project (proj_id) using index pdep_budget_project_fk_proj_id;
alter table salary_history add foreign key (emp_no) references employee (emp_no) using index sal_hist_employee_fk_emp_no;
alter table sales add foreign key (cust_no) references customer (cust_no) using index sales_customer_fk_cust_no;
alter table sales add foreign key (sales_rep) references employee (emp_no) using index sales_employee_fk_sales_rep;
commit;


-- ##########################################
-- ###   I N D E X   S T A T I S T I C S  ###
-- ##########################################
-- Added 16.01.2026: recalc index statistics, including PK/FK indices!
-- We have to use fresh index statistics for test which checks rule described by dimitr for
-- 893488bb "(Simplified but still) cost-based choice between LOOP and HASH semi-joins"
-- (letter 15.01.2026 09:12)
-- Also, this is needed for correct explained plans in bugs/gh_8061_test.py (HJ vs NL).
-- ##########################################
set transaction no wait;
set term ^;
execute block as
begin
    for
        select ri.rdb$index_name as idx_name from rdb$indices ri
        as cursor c
    do begin
        execute statement 'set statistics index ' || trim(c.idx_name);
    end
end
^
set term ;^
commit;
