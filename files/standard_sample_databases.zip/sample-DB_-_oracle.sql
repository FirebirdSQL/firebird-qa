    recreate table emp (id int);
    recreate table dept (id int);
    commit;

    set term ^;
    execute block as
    begin
        begin
            execute statement 'drop sequence emp_table_seq';
        when any do begin end
        end
        begin
            execute statement 'drop sequence dept_table_seq';
        when any do begin end
        end
    end
    ^
    set term ;^
    commit;

    create sequence emp_table_seq start with 1000;
    create sequence dept_table_seq start with 41;

    recreate table dept (
        deptno smallint,
        dname varchar(14),
        loc varchar(13),
        constraint dept_pk primary key (deptno)
    );

    insert into dept values (10, 'accounting', 'new york');
    insert into dept values (20, 'research',   'dallas');
    insert into dept values (30, 'sales',      'chicago');
    insert into dept values (40, 'operations', 'boston');
    commit;

    recreate table emp (
        empno smallint not null,
        ename varchar(10),
        job varchar(9),
        mgr smallint,
        hiredate date,
        sal numeric(7, 2),
        comm numeric(7, 2),
        deptno smallint,
        constraint employee_pk primary key (empno),
        constraint works_in_dept foreign key (deptno) references dept on delete set null
    );

    -- https://code.google.com/archive/p/adf-samples-demos/downloads
    insert into emp values(7369, 'smith',  'clerk',     7902,'17-dec-1980',  800, null, 20);
    insert into emp values(7499, 'allen',  'salesman',  7698,'20-feb-1981', 1600,  300, 30);
    insert into emp values(7521, 'ward',   'salesman',  7698,'22-feb-1981', 1250,  500, 30);
    insert into emp values(7566, 'jones',  'manager',   7839,'2-apr-1981',  2975, null, 20);
    insert into emp values(7654, 'martin', 'salesman',  7698,'28-sep-1981', 1250, 1400, 30);
    insert into emp values(7698, 'blake',  'manager',   7839,'1-may-1981',  2850, null, 30);
    insert into emp values(7782, 'clark',  'manager',   7839,'9-jun-1981',  2450, null, 10);
    insert into emp values(7788, 'scott',  'analyst',   7566,'09-dec-1982', 3000, null, 20); -- <<< 19-apr-1987 ?
    insert into emp values(7839, 'king',   'president', null,'17-nov-1981', 5000, null, 10);
    insert into emp values(7844, 'turner', 'salesman',  7698,'8-sep-1981',  1500,    0, 30);
    insert into emp values(7876, 'adams',  'clerk',     7788,'12-jan-1983', 1100, null, 20); -- << 23-may-1987 ?
    insert into emp values(7900, 'james',  'clerk',     7698,'3-dec-1981',   950, null, 30);
    insert into emp values(7902, 'ford',   'analyst',   7566,'3-dec-1981',  3000, null, 20);
    insert into emp values(7934, 'miller', 'clerk',     7782,'23-jan-1982', 1300, null, 10);
    commit;

